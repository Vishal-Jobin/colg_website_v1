import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import { Registration } from './models/Registration.js';
import { ContactMessage } from './models/ContactMessage.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const MONGODB_URI = process.env.MONGODB_URI || '';

let isMongoConnected = false;

// Middleware
app.use(cors());
app.use(express.json({ limit: '1mb' }));

// Attempt database connection if URI is configured
if (MONGODB_URI) {
  mongoose
    .connect(MONGODB_URI)
    .then(() => {
      isMongoConnected = true;
      console.log('Successfully connected to MongoDB');
    })
    .catch((err) => {
      isMongoConnected = false;
      console.warn('MongoDB connection failed:', err.message);
    });
} else {
  console.info('MongoDB URI not provided. The server will run in fallback mode.');
}

// 1. Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    service: 'Confluence 3.0 API',
    database: {
      connected: isMongoConnected,
      status: isMongoConnected ? 'connected' : 'disconnected / not configured'
    }
  });
});

// 2. Submit Registration Interest
app.post('/api/registrations', async (req, res, next) => {
  try {
    const { name, email, phone, institution, passType } = req.body;

    if (!name || !email || !passType) {
      return res.status(400).json({
        success: false,
        error: 'Name, email, and passType are required fields.'
      });
    }

    if (!['business', 'academic', 'young'].includes(passType)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid passType selected.'
      });
    }

    if (!isMongoConnected) {
      return res.status(503).json({
        success: false,
        error: 'Database is currently not connected. Please configure MONGODB_URI in server/.env.'
      });
    }

    const registration = await Registration.create({
      name,
      email,
      phone,
      institution,
      passType
    });

    res.status(201).json({
      success: true,
      message: 'Registration interest submitted successfully.',
      data: {
        id: registration._id,
        name: registration.name,
        passType: registration.passType
      }
    });
  } catch (error) {
    next(error);
  }
});

// 3. Submit Contact Form Message
app.post('/api/contact', async (req, res, next) => {
  try {
    const { name, email, subject, message } = req.body;

    if (!name || !name.trim()) {
      return res.status(400).json({ success: false, error: 'Please enter your full name.' });
    }

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      return res.status(400).json({ success: false, error: 'Please enter a valid email address.' });
    }

    if (!subject || !subject.trim()) {
      return res.status(400).json({ success: false, error: 'Please select a subject.' });
    }

    if (!message || message.trim().length < 10) {
      return res.status(400).json({
        success: false,
        error: 'Your message should be at least 10 characters long.'
      });
    }

    if (!isMongoConnected) {
      return res.status(503).json({
        success: false,
        error: 'Database is currently not connected. Please configure MONGODB_URI in server/.env.'
      });
    }

    const contactEntry = await ContactMessage.create({
      name: name.trim(),
      email: email.trim(),
      subject: subject.trim(),
      message: message.trim()
    });

    res.status(201).json({
      success: true,
      message: 'Thank you! Your message has been received by the Confluence 3.0 team.',
      id: contactEntry._id
    });
  } catch (error) {
    next(error);
  }
});

// Centralized Error Handling Middleware
app.use((err, req, res, next) => {
  console.error('API Error:', err);
  if (err.name === 'ValidationError') {
    const messages = Object.values(err.errors).map((e) => e.message);
    return res.status(400).json({ success: false, error: messages.join(', ') });
  }
  res.status(500).json({
    success: false,
    error: 'An unexpected server error occurred.'
  });
});

app.listen(PORT, () => {
  console.log(`Confluence 3.0 API Server running on port ${PORT}`);
});
