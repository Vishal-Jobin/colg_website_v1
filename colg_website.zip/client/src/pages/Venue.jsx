import React, { useState } from 'react';
import { Search, MapPin } from 'lucide-react';
import data from '../data.json';

export const Venue = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const venues = data.workshops.filter((w) => {
    const q = searchTerm.toLowerCase();
    return (
      (w.venue && w.venue.toLowerCase().includes(q)) ||
      (w.block && w.block.toLowerCase().includes(q)) ||
      w.title.toLowerCase().includes(q)
    );
  });

  return (
    <div className="venue-page">
      <section className="ws-hero">
        <div className="ws-hero__content">
          <p className="ws-hero__eyebrow">Confluence 3.0</p>
          <h1 className="ws-hero__title">Find My Workshop Venue</h1>
          <p className="ws-hero__text">
            Search by workshop title, room number, or block name across the Rajagiri campus.
          </p>
        </div>
      </section>

      <div style={{ maxWidth: '800px', margin: '3rem auto 5rem', padding: '0 1.5rem' }}>
        <div style={{ position: 'relative', marginBottom: '2.5rem' }}>
          <Search size={18} style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)', color: '#64748b' }} />
          <input
            type="text"
            placeholder="Search venue or workshop name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{
              width: '100%',
              padding: '0.85rem 1rem 0.85rem 2.8rem',
              borderRadius: '9999px',
              border: '1px solid #cbd5e1',
              backgroundColor: '#fff',
              fontSize: '1rem',
              outline: 'none',
              boxShadow: '0 2px 6px rgba(0,0,0,0.05)'
            }}
          />
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {venues.map((v, idx) => (
            <div
              key={idx}
              style={{
                backgroundColor: '#fff',
                border: '1px solid #e2e8f0',
                borderRadius: '12px',
                padding: '1.25rem 1.5rem',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                boxShadow: '0 2px 6px rgba(0,0,0,0.02)'
              }}
            >
              <div>
                <h3 style={{ fontSize: '1.05rem', fontWeight: 700, color: '#0f172a' }}>{v.title}</h3>
                <p style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.88rem', color: '#0A2540', fontWeight: 600, marginTop: '0.3rem' }}>
                  <MapPin size={15} /> {v.venue || 'RSET Campus'}
                </p>
              </div>
              {v.block && (
                <span
                  style={{
                    backgroundColor: '#f1f5f9',
                    color: '#475569',
                    padding: '0.3rem 0.75rem',
                    borderRadius: '6px',
                    fontSize: '0.8rem',
                    fontWeight: 600,
                    whiteSpace: 'nowrap'
                  }}
                >
                  {v.block}
                </span>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
