import React, { useState } from 'react';
import { Calendar, Clock, MapPin, Search, ExternalLink, X } from 'lucide-react';
import data from '../data.json';

export const Workshops = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedWorkshop, setSelectedWorkshop] = useState(null);

  const filtered = data.workshops.filter((ws) => {
    const q = searchTerm.toLowerCase();
    return (
      ws.title.toLowerCase().includes(q) ||
      (ws.resourcePerson && ws.resourcePerson.toLowerCase().includes(q)) ||
      (ws.venue && ws.venue.toLowerCase().includes(q))
    );
  });

  return (
    <div className="workshops-page">
      {/* Hero */}
      <section className="ws-hero">
        <div className="ws-hero__content">
          <p className="ws-hero__eyebrow">Confluence 3.0</p>
          <h1 className="ws-hero__title">Workshops</h1>
          <p className="ws-hero__text">
            Interactive sessions designed to bridge theory and practice — learn, build, and collaborate with industry experts across engineering and technology domains.
          </p>
        </div>
      </section>

      {/* Filter / Search Bar */}
      <div className="ws-search-bar" style={{ maxWidth: '1200px', margin: '2rem auto 0', padding: '0 1.5rem' }}>
        <div style={{ position: 'relative', maxWidth: '480px', margin: '0 auto' }}>
          <Search size={18} style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)', color: '#64748b' }} />
          <input
            type="text"
            placeholder="Search by topic, resource person, or venue..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{
              width: '100%',
              padding: '0.85rem 1rem 0.85rem 2.8rem',
              borderRadius: '9999px',
              border: '1px solid #cbd5e1',
              backgroundColor: '#fff',
              fontSize: '0.95rem',
              color: '#0f172a',
              outline: 'none',
              boxShadow: '0 2px 6px rgba(0,0,0,0.05)'
            }}
          />
        </div>
      </div>

      {/* Workshop Cards Grid */}
      <section className="ws-grid-section" style={{ maxWidth: '1200px', margin: '2rem auto 4rem', padding: '0 1.5rem' }}>
        <div className="ws-cards-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '1.5rem' }}>
          {filtered.map((ws, idx) => (
            <article
              key={ws.id || idx}
              className={`ws-card ${ws.soldOut ? 'ws-card--sold-out' : ''}`}
              onClick={() => setSelectedWorkshop(ws)}
              style={{
                cursor: 'pointer',
                background: '#ffffff',
                border: '1px solid #e2e8f0',
                borderRadius: '12px',
                padding: '1.5rem',
                position: 'relative',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                transition: 'transform 0.2s ease, box-shadow 0.2s ease',
                boxShadow: '0 4px 12px rgba(0,0,0,0.04)'
              }}
            >
              <div className="ws-card__accent" aria-hidden="true" />
              {ws.soldOut && (
                <span
                  style={{
                    position: 'absolute',
                    top: '1rem',
                    right: '1rem',
                    backgroundColor: '#fee2e2',
                    color: '#dc2626',
                    fontSize: '0.75rem',
                    fontWeight: 700,
                    padding: '0.2rem 0.6rem',
                    borderRadius: '4px'
                  }}
                >
                  SOLD OUT
                </span>
              )}

              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                  <span style={{ fontSize: '1.1rem', fontWeight: 800, color: '#0A2540' }}>
                    #{String(idx + 1).padStart(2, '0')}
                  </span>
                  <div style={{ display: 'flex', gap: '0.75rem', fontSize: '0.8rem', color: '#64748b' }}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                      <Calendar size={13} /> 1 Sep 2026
                    </span>
                    <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                      <Clock size={13} /> {ws.time}
                    </span>
                  </div>
                </div>

                <h3 style={{ fontSize: '1.1rem', fontWeight: 700, color: '#0f172a', lineHeight: 1.4, marginBottom: '1rem' }}>
                  {ws.title}
                </h3>
              </div>

              <div>
                <div style={{ borderTop: '1px solid #f1f5f9', paddingTop: '0.85rem' }}>
                  <span style={{ fontSize: '0.75rem', textTransform: 'uppercase', color: '#94a3b8', fontWeight: 600, letterSpacing: '0.5px' }}>
                    Resource Person
                  </span>
                  <p style={{ fontSize: '0.9rem', fontWeight: 600, color: '#1e293b', marginTop: '0.2rem' }}>
                    {ws.resourcePerson}
                  </p>
                  {ws.venue && (
                    <p style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.8rem', color: '#475569', marginTop: '0.4rem' }}>
                      <MapPin size={13} color="#0A2540" /> {ws.venue}
                    </p>
                  )}
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* Workshop Modal */}
      {selectedWorkshop && (
        <div
          className="ws-modal-overlay"
          onClick={() => setSelectedWorkshop(null)}
          style={{
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(10, 37, 64, 0.75)',
            backdropFilter: 'blur(4px)',
            zIndex: 1000,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '1.5rem'
          }}
        >
          <div
            className="ws-modal-card"
            onClick={(e) => e.stopPropagation()}
            style={{
              backgroundColor: '#ffffff',
              borderRadius: '16px',
              maxWidth: '600px',
              width: '100%',
              padding: '2rem',
              position: 'relative',
              boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.2)'
            }}
          >
            <button
              onClick={() => setSelectedWorkshop(null)}
              style={{
                position: 'absolute',
                top: '1.25rem',
                right: '1.25rem',
                border: 'none',
                background: 'transparent',
                cursor: 'pointer',
                color: '#64748b'
              }}
            >
              <X size={24} />
            </button>

            {selectedWorkshop.soldOut && (
              <span
                style={{
                  display: 'inline-block',
                  backgroundColor: '#fee2e2',
                  color: '#dc2626',
                  fontSize: '0.8rem',
                  fontWeight: 700,
                  padding: '0.3rem 0.75rem',
                  borderRadius: '6px',
                  marginBottom: '1rem'
                }}
              >
                SOLD OUT
              </span>
            )}

            <h2 style={{ fontSize: '1.4rem', fontWeight: 800, color: '#0A2540', lineHeight: 1.3, marginBottom: '1rem' }}>
              {selectedWorkshop.title}
            </h2>

            <div style={{ backgroundColor: '#f8fafc', padding: '1rem', borderRadius: '8px', marginBottom: '1.25rem' }}>
              <p style={{ fontSize: '0.8rem', color: '#64748b', textTransform: 'uppercase', fontWeight: 600 }}>Speaker / Instructor</p>
              <p style={{ fontSize: '1rem', fontWeight: 700, color: '#0f172a', marginTop: '0.25rem' }}>
                {selectedWorkshop.resourcePerson}
              </p>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1.5rem' }}>
              <div style={{ border: '1px solid #e2e8f0', padding: '0.75rem', borderRadius: '8px' }}>
                <span style={{ fontSize: '0.75rem', color: '#64748b' }}>Date & Time</span>
                <p style={{ fontWeight: 600, color: '#0f172a', fontSize: '0.88rem', marginTop: '0.2rem' }}>
                  1 Sep 2026, {selectedWorkshop.time}
                </p>
              </div>
              <div style={{ border: '1px solid #e2e8f0', padding: '0.75rem', borderRadius: '8px' }}>
                <span style={{ fontSize: '0.75rem', color: '#64748b' }}>Venue & Block</span>
                <p style={{ fontWeight: 600, color: '#0f172a', fontSize: '0.88rem', marginTop: '0.2rem' }}>
                  {selectedWorkshop.venue || 'Campus Lab'}
                </p>
              </div>
            </div>

            {selectedWorkshop.registrationLink && !selectedWorkshop.soldOut && (
              <a
                href={selectedWorkshop.registrationLink}
                target="_blank"
                rel="noreferrer"
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '0.5rem',
                  backgroundColor: '#0A2540',
                  color: '#fff',
                  padding: '0.85rem',
                  borderRadius: '8px',
                  fontWeight: 600,
                  textDecoration: 'none'
                }}
              >
                Register for Workshop <ExternalLink size={16} />
              </a>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
