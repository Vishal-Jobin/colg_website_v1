import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Clock } from 'lucide-react';
import data from '../data.json';

export const ScheduleDay = ({ dayNumber }) => {
  const isDay1 = dayNumber === 1;
  const items = isDay1 ? data.scheduleDay1 : data.scheduleDay2;
  const dayMeta = isDay1 ? data.days[0] : data.days[1];

  return (
    <div className="schedule-page">
      <section className="s-hero" style={{ background: '#0A2540', padding: '4rem 1.5rem', color: '#fff', textAlign: 'center' }}>
        <div style={{ maxWidth: '800px', margin: '0 auto' }}>
          <Link
            to="/"
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.4rem',
              color: '#d4af37',
              textDecoration: 'none',
              fontSize: '0.9rem',
              fontWeight: 600,
              marginBottom: '1rem'
            }}
          >
            <ArrowLeft size={16} /> Back to Home
          </Link>
          <p style={{ textTransform: 'uppercase', letterSpacing: '2px', color: '#93c5fd', fontSize: '0.85rem' }}>
            Confluence 3.0
          </p>
          <h1 style={{ fontSize: '2.4rem', fontWeight: 900, marginTop: '0.5rem', color: '#ffffff' }}>
            Programme Schedule — Day {dayNumber}
          </h1>
          <p style={{ color: '#cbd5e1', fontSize: '1rem', marginTop: '0.5rem' }}>
            {dayMeta ? `${dayMeta.date} • ${dayMeta.time}` : ''}
          </p>
        </div>
      </section>

      <div style={{ maxWidth: '800px', margin: '3.5rem auto 5rem', padding: '0 1.5rem' }}>
        <div style={{ position: 'relative', borderLeft: '2px solid #e2e8f0', marginLeft: '1rem', paddingLeft: '2rem' }}>
          {items.map((event, idx) => (
            <div key={idx} style={{ marginBottom: '2.5rem', position: 'relative' }}>
              {/* Timeline marker */}
              <div
                style={{
                  position: 'absolute',
                  left: '-2.45rem',
                  top: '0.2rem',
                  width: '14px',
                  height: '14px',
                  borderRadius: '50%',
                  backgroundColor: '#0A2540',
                  border: '3px solid #d4af37'
                }}
              />

              <div
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '0.35rem',
                  backgroundColor: '#f1f5f9',
                  color: '#0A2540',
                  padding: '0.25rem 0.65rem',
                  borderRadius: '999px',
                  fontSize: '0.8rem',
                  fontWeight: 700,
                  marginBottom: '0.5rem'
                }}
              >
                <Clock size={12} />
                {event.time}
              </div>

              <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: '#0f172a', margin: '0.25rem 0' }}>
                {event.title}
              </h3>

              {event.subtitle && (
                <p style={{ fontSize: '0.92rem', color: '#475569', lineHeight: 1.5, marginTop: '0.35rem' }}>
                  {event.subtitle}
                </p>
              )}

              {event.type && (
                <span
                  style={{
                    display: 'inline-block',
                    marginTop: '0.5rem',
                    fontSize: '0.75rem',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px',
                    color: '#64748b',
                    fontWeight: 600
                  }}
                >
                  Type: {event.type}
                </span>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
