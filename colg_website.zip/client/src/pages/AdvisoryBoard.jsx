import React from 'react';
import { ExternalLink, User } from 'lucide-react';
import data from '../data.json';

export const AdvisoryBoard = () => {
  return (
    <div className="advisory-page">
      <section className="ws-hero">
        <div className="ws-hero__content">
          <p className="ws-hero__eyebrow">Confluence 3.0</p>
          <h1 className="ws-hero__title">Advisory Board</h1>
          <p className="ws-hero__text">
            Guiding the vision and strategic direction of Confluence 3.0 — distinguished patrons, academic leaders, and advisors from Rajagiri and industry.
          </p>
        </div>
      </section>

      <div style={{ maxWidth: '1200px', margin: '3rem auto', padding: '0 1.5rem' }}>
        {data.advisoryBoard.map((category) => (
          <div key={category.id} style={{ marginBottom: '4rem' }}>
            <div style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
              <h2 style={{ fontSize: '1.8rem', fontWeight: 800, color: '#0A2540' }}>
                {category.title}
              </h2>
              <div style={{ width: '60px', height: '3px', backgroundColor: '#d4af37', margin: '0.75rem auto 0' }} />
            </div>

            <div
              style={{
                display: 'grid',
                gridTemplateColumns: category.variant === 'spotlight'
                  ? 'minmax(280px, 420px)'
                  : 'repeat(auto-fit, minmax(280px, 1fr))',
                justifyContent: 'center',
                gap: '2rem'
              }}
            >
              {category.members.map((member, mIdx) => (
                <div
                  key={mIdx}
                  style={{
                    backgroundColor: '#ffffff',
                    border: '1px solid #e2e8f0',
                    borderRadius: '16px',
                    padding: '2rem',
                    textAlign: 'center',
                    boxShadow: '0 4px 15px rgba(0,0,0,0.03)',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center'
                  }}
                >
                  <div
                    style={{
                      width: '120px',
                      height: '120px',
                      borderRadius: '50%',
                      overflow: 'hidden',
                      marginBottom: '1.25rem',
                      backgroundColor: '#f1f5f9',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      border: '3px solid #e2e8f0'
                    }}
                  >
                    {member.imageUrl ? (
                      <img
                        src={`https://confluence.org.in${member.imageUrl}`}
                        alt={member.name}
                        style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                        onError={(e) => {
                          e.target.style.display = 'none';
                          e.target.nextSibling.style.display = 'block';
                        }}
                      />
                    ) : null}
                    <User size={48} color="#94a3b8" style={{ display: member.imageUrl ? 'none' : 'block' }} />
                  </div>

                  <h3 style={{ fontSize: '1.15rem', fontWeight: 700, color: '#0f172a', marginBottom: '0.35rem' }}>
                    {member.name}
                  </h3>
                  <p style={{ fontSize: '0.88rem', color: '#0A2540', fontWeight: 600, marginBottom: '0.25rem' }}>
                    {member.designation}
                  </p>
                  {member.organization && (
                    <p style={{ fontSize: '0.8rem', color: '#64748b', lineHeight: 1.4 }}>
                      {member.organization}
                    </p>
                  )}

                  {member.linkedinUrl && (
                    <a
                      href={member.linkedinUrl}
                      target="_blank"
                      rel="noreferrer"
                      style={{
                        marginTop: '1rem',
                        color: '#0077b5',
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '0.35rem',
                        fontSize: '0.85rem',
                        fontWeight: 600,
                        textDecoration: 'none'
                      }}
                      aria-label={`${member.name} LinkedIn Profile`}
                    >
                      <ExternalLink size={16} /> LinkedIn
                    </a>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
