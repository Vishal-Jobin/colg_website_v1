import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Clock, Ticket, ArrowRight } from 'lucide-react';
import data from '../data.json';

// Target summit date
const SUMMIT_DATE = new Date('2026-08-31T16:00:00+05:30').getTime();

function calculateTimeLeft() {
  const diff = Math.max(SUMMIT_DATE - Date.now(), 0);
  const totalSecs = Math.floor(diff / 1000);
  return {
    days: Math.floor(totalSecs / 86400),
    hours: Math.floor((totalSecs % 86400) / 3600),
    minutes: Math.floor((totalSecs % 3600) / 60),
    seconds: totalSecs % 60
  };
}

export const Home = () => {
  const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const isStarted =
    timeLeft.days === 0 &&
    timeLeft.hours === 0 &&
    timeLeft.minutes === 0 &&
    timeLeft.seconds === 0;

  return (
    <div className="home-page">
      {/* 1. Hero Section */}
      <section id="home" className="hero">
        <div className="hero__banner-container">
          <div className="hero__artistic-backdrop">
            <div className="hero__aurora" />
          </div>
          <img
            src="/images/new_front.png"
            alt="Confluence 3.0 — The Largest Industry–Academia Summit"
            className="hero__text-overlay"
            onError={(e) => {
              e.target.style.display = 'none';
              e.target.nextSibling.style.display = 'block';
            }}
          />
          <div className="hero__fallback-heading" style={{ display: 'none', textAlign: 'center' }}>
            <h1 style={{ fontSize: '3.5rem', fontWeight: 900, color: '#fff', textTransform: 'uppercase', letterSpacing: '2px' }}>
              CONFLUENCE <span style={{ color: '#d4af37' }}>3.0</span>
            </h1>
            <p style={{ color: '#93c5fd', fontSize: '1.25rem', marginTop: '0.5rem' }}>
              The Largest Industry–Academia Summit
            </p>
          </div>
          <h2 className="hero__subtitle">India Impact Of AI</h2>
          <div aria-hidden="true" className="hero__glow" />
        </div>
      </section>

      {/* Hero CTA Button */}
      <div style={{ display: 'flex', justifyContent: 'center', padding: '2.5rem 1rem' }}>
        <Link
          to="/tickets"
          className="hero__cta"
          style={{ position: 'static', transform: 'none' }}
        >
          <Ticket className="hero__cta-icon" size={20} />
          Get Summit Pass
        </Link>
      </div>

      {/* 2. Program Overview Section */}
      <section id="program" className="program">
        <div className="program__container">
          <div className="program__header">
            <p className="program__eyebrow">Programme Overview</p>
            <p className="program__intro">
              Confluence 3.0 is the third edition of the largest industry-academia summit, organized by Rajagiri School of Engineering & Technology. In its Silver Jubilee Year, RSET aims to bring together industry leaders, distinguished academics, and budding innovators under one roof — to exchange ideas, forge collaborations, and shape the future of engineering, management, and the applied sciences through this summit.
            </p>
            <h2 className="program__title">Explore the Summit</h2>
          </div>

          <div className="program__events">
            {data.days.map((item) => (
              <div
                key={item.id}
                className="program__event-card"
                style={{
                  background: item.id === 'day1'
                    ? 'linear-gradient(135deg, rgba(10,37,64,0.92) 0%, rgba(14,60,110,0.85) 100%)'
                    : 'linear-gradient(135deg, rgba(20,40,70,0.92) 0%, rgba(26,54,93,0.85) 100%)'
                }}
              >
                <div className="program__event-overlay" />
                <div className="program__event-content">
                  <div className="program__event-day">{item.day}</div>
                  <h3 className="program__event-title">{item.title}</h3>
                  <div className="program__event-details">
                    <span className="program__event-detail">
                      <Calendar size={18} />
                      {item.date}
                    </span>
                    <span className="program__event-detail">
                      <Clock size={18} />
                      {item.time}
                    </span>
                  </div>
                  <Link to={item.to} className="program__event-btn">
                    View Schedule
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. Countdown Section */}
      <section id="countdown" className="countdown">
        <div className="countdown__accent" aria-hidden="true" />
        <div className="countdown__container">
          <h2 className="countdown__title">Confluence Countdown Begins</h2>
          <p className="countdown__subtitle">
            Confluence 3.0 opens on August 31, 2026 at 4:00 PM IST at Rajagiri School of Engineering & Technology, Kakkanad.
          </p>

          {isStarted ? (
            <p className="countdown__started">The summit has begun — welcome to Confluence 3.0!</p>
          ) : (
            <div className="countdown__units">
              {[
                { key: 'days', label: 'Days' },
                { key: 'hours', label: 'Hours' },
                { key: 'minutes', label: 'Minutes' },
                { key: 'seconds', label: 'Seconds' }
              ].map(({ key, label }, idx) => (
                <div key={key} className="countdown__unit">
                  {idx > 0 && (
                    <span aria-hidden="true" className="countdown__colon">:</span>
                  )}
                  <div className="countdown__card">
                    <p className="countdown__number">
                      {String(timeLeft[key]).padStart(2, '0')}
                    </p>
                    <p className="countdown__label">{label}</p>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="countdown__meta">
            <span className="countdown__meta-item">
              <Calendar className="countdown__meta-icon" size={18} />
              August 31, 2026
            </span>
            <span className="countdown__meta-item">
              <Clock className="countdown__meta-icon" size={18} />
              4:00 PM IST
            </span>
          </div>
        </div>
      </section>

      {/* 4. Registration Call to Action */}
      <section id="register" className="register">
        <div className="register__container">
          <p className="register__eyebrow">Registration Open</p>
          <h2 className="register__title">Secure your seat at the Summit</h2>
          <p className="register__text">
            Passes for Confluence 3.0 are now open to students, faculty, researchers, and industry professionals. Reserve your place before August 31, 2026.
          </p>
          <div className="register__actions">
            <Link to="/tickets" className="register__btn register__btn--primary">
              <Ticket className="register__btn-icon" size={18} />
              Get Summit Pass
            </Link>
            <a href="#program" className="register__btn register__btn--secondary">
              View the Programme
              <ArrowRight className="register__btn-icon" size={18} />
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};
