import React from 'react';
import data from '../data.json';

export const SponsorsPartners = () => {
  return (
    <div className="sponsors-page">
      <section className="ws-hero">
        <div className="ws-hero__content">
          <p className="ws-hero__eyebrow">Confluence 3.0</p>
          <h1 className="ws-hero__title">Sponsors & Partners</h1>
          <p className="ws-hero__text">
            Proudly supported by leading industry partners driving innovation and excellence in engineering and technology education.
          </p>
        </div>
      </section>

      <div style={{ maxWidth: '1200px', margin: '3.5rem auto', padding: '0 1.5rem' }}>
        {data.sponsors.map((category) => (
          <div key={category.id} style={{ marginBottom: '4rem', textAlign: 'center' }}>
            <h2 style={{ fontSize: '1.6rem', fontWeight: 800, color: '#0A2540', marginBottom: '0.5rem' }}>
              {category.title}
            </h2>
            <div style={{ width: '50px', height: '3px', backgroundColor: '#d4af37', margin: '0 auto 2rem' }} />

            <div
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                justifyContent: 'center',
                alignItems: 'center',
                gap: '2rem'
              }}
            >
              {category.members.map((sponsor, sIdx) => (
                <div
                  key={sIdx}
                  style={{
                    backgroundColor: '#ffffff',
                    border: '1px solid #e2e8f0',
                    borderRadius: '12px',
                    padding: '1.5rem 2rem',
                    minWidth: '220px',
                    maxWidth: '320px',
                    minHeight: '110px',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.03)'
                  }}
                >
                  {sponsor.logo ? (
                    <img
                      src={sponsor.logo}
                      alt={sponsor.name}
                      style={{ maxHeight: '60px', maxWidth: '180px', objectFit: 'contain' }}
                      onError={(e) => {
                        e.target.style.display = 'none';
                        e.target.nextSibling.style.display = 'block';
                      }}
                    />
                  ) : null}
                  <span
                    style={{
                      display: sponsor.logo ? 'none' : 'block',
                      fontWeight: 700,
                      color: '#0A2540',
                      fontSize: '1.1rem'
                    }}
                  >
                    {sponsor.name}
                  </span>
                  {sponsor.tagline && (
                    <span style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.25rem' }}>
                      {sponsor.tagline}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
