import React from 'react';
import { ExternalLink, User } from 'lucide-react';
import data from '../data.json';

export const Speakers = () => {
  return (
    <div className="speakers-page">
      <section className="ws-hero">
        <div className="ws-hero__content">
          <p className="ws-hero__eyebrow">Confluence 3.0</p>
          <h1 className="ws-hero__title">Distinguished Speakers</h1>
          <p className="ws-hero__text">
            Meet the luminaries, policy makers, industry titans, and pioneers who will share transformative perspectives at Confluence 3.0.
          </p>
        </div>
      </section>

      <div style={{ maxWidth: '1200px', margin: '3.5rem auto', padding: '0 1.5rem' }}>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
            gap: '2rem'
          }}
        >
          {data.speakers.map((speaker) => (
            <div
              key={speaker.id}
              style={{
                backgroundColor: '#ffffff',
                border: '1px solid #e2e8f0',
                borderRadius: '16px',
                padding: '2rem 1.5rem',
                textAlign: 'center',
                boxShadow: '0 4px 15px rgba(0,0,0,0.03)',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'space-between',
                transition: 'transform 0.2s ease, box-shadow 0.2s ease'
              }}
            >
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                <div
                  style={{
                    width: '130px',
                    height: '130px',
                    borderRadius: '50%',
                    overflow: 'hidden',
                    marginBottom: '1.25rem',
                    backgroundColor: '#f1f5f9',
                    border: '3px solid #0A2540',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  {speaker.image ? (
                    <img
                      src={speaker.image.startsWith('http') ? speaker.image : `https://confluence.org.in${speaker.image}`}
                      alt={speaker.name}
                      style={{
                        width: '100%',
                        height: '100%',
                        objectFit: 'cover',
                        objectPosition: speaker.imagePosition || 'center'
                      }}
                      onError={(e) => {
                        e.target.style.display = 'none';
                        e.target.nextSibling.style.display = 'block';
                      }}
                    />
                  ) : null}
                  <User size={48} color="#94a3b8" style={{ display: speaker.image ? 'none' : 'block' }} />
                </div>

                <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: '#0A2540', marginBottom: '0.4rem' }}>
                  {speaker.name}
                </h3>

                {Array.isArray(speaker.title) ? (
                  speaker.title.map((t, idx) => (
                    <p key={idx} style={{ fontSize: '0.85rem', color: '#475569', lineHeight: 1.4 }}>
                      {t}
                    </p>
                  ))
                ) : (
                  <p style={{ fontSize: '0.88rem', color: '#475569', lineHeight: 1.4 }}>
                    {speaker.title}
                  </p>
                )}
              </div>

              {speaker.linkedinUrl && (
                <div style={{ marginTop: '1.25rem' }}>
                  <a
                    href={speaker.linkedinUrl}
                    target="_blank"
                    rel="noreferrer"
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '0.35rem',
                      color: '#0077b5',
                      fontSize: '0.82rem',
                      fontWeight: 600,
                      textDecoration: 'none'
                    }}
                  >
                    <ExternalLink size={16} /> LinkedIn
                  </a>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
