import React from 'react';
import { Link } from 'react-router-dom';

export const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer__bottom">
        <p className="footer__copyright">
          Copyright © Developed by RSoft2026 All rights reserved | Confluence 3.0
        </p>
      </div>
    </footer>
  );
};
