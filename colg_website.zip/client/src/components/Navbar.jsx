import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

const NAV_ITEMS = [
  { label: 'Home', path: '/' },
  { label: 'Workshops', path: '/workshops' },
  { label: 'Advisory Board', path: '/advisory-board' },
  { label: 'Speakers', path: '/speakers' },
  { label: 'Sponsors/Partners', path: '/sponsors-partners' },
  { label: 'Tickets', path: '/tickets' },
  { label: 'Contact', path: '/contact' }
];

export const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="navbar">
      <nav className="navbar__nav" aria-label="Primary">
        <div className="navbar__brand">
          <Link to="/" aria-label="RSET Silver Jubilee — Confluence 3.0">
            <img
              src="/images/rset-silver-jubilee-logo.png"
              alt="RSET Silver Jubilee"
              className="navbar__logo"
              onError={(e) => {
                // Fallback elegant logo text if image not loaded
                e.target.style.display = 'none';
                e.target.nextSibling.style.display = 'flex';
              }}
            />
            <div
              className="navbar__brand-fallback"
              style={{
                display: 'none',
                flexDirection: 'column',
                fontWeight: 800,
                color: '#fff',
                fontSize: '1.1rem',
                lineHeight: 1.1
              }}
            >
              <span>RSET</span>
              <span style={{ color: '#d4af37', fontSize: '0.75rem', letterSpacing: '2px' }}>
                SILVER JUBILEE
              </span>
            </div>
          </Link>
        </div>

        <div className="navbar__links">
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `navbar__link ${isActive ? 'navbar__link--active' : ''}`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </div>

        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          aria-expanded={isOpen}
          aria-controls="mobile-menu"
          aria-label="Toggle navigation menu"
          className="navbar__toggle"
        >
          {isOpen ? (
            <X className="navbar__toggle-icon" size={24} />
          ) : (
            <Menu className="navbar__toggle-icon" size={24} />
          )}
        </button>
      </nav>

      {isOpen && (
        <div id="mobile-menu" className="navbar__mobile-menu">
          <div className="navbar__mobile-links">
            {NAV_ITEMS.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={() => setIsOpen(false)}
                className={({ isActive }) =>
                  `navbar__mobile-link ${isActive ? 'navbar__mobile-link--active' : ''}`
                }
              >
                {item.label}
              </NavLink>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};
