import crypto from 'crypto';

const tokenSecret = () => process.env.ADMIN_TOKEN_SECRET || process.env.ADMIN_PASSWORD;

export function adminLogin(req, res) {
  const { username, password } = req.body || {};
  const expectedUser = process.env.ADMIN_USERNAME;
  const expectedPassword = process.env.ADMIN_PASSWORD;
  if (!expectedUser || !expectedPassword || !tokenSecret()) {
    return res.status(503).json({ error: 'Admin credentials are not configured on the server.' });
  }
  const safeEqual = (a, b) => {
    const aa = Buffer.from(String(a || ''));
    const bb = Buffer.from(String(b || ''));
    return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
  };
  if (!safeEqual(username, expectedUser) || !safeEqual(password, expectedPassword)) {
    return res.status(401).json({ error: 'Invalid username or password.' });
  }
  const payload = Buffer.from(JSON.stringify({ sub: expectedUser, exp: Date.now() + 8 * 60 * 60 * 1000 })).toString('base64url');
  const signature = crypto.createHmac('sha256', tokenSecret()).update(payload).digest('base64url');
  res.json({ token: `${payload}.${signature}`, username: expectedUser });
}

export function requireAdmin(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const [payload, signature] = token.split('.');
  if (!payload || !signature || !tokenSecret()) return res.status(401).json({ error: 'Admin authentication required.' });
  const expected = crypto.createHmac('sha256', tokenSecret()).update(payload).digest();
  let actual;
  try { actual = Buffer.from(signature, 'base64url'); } catch { return res.status(401).json({ error: 'Invalid admin token.' }); }
  if (actual.length !== expected.length || !crypto.timingSafeEqual(actual, expected)) return res.status(401).json({ error: 'Invalid admin token.' });
  try {
    const claims = JSON.parse(Buffer.from(payload, 'base64url').toString());
    if (!claims.sub || claims.exp < Date.now() || claims.sub !== process.env.ADMIN_USERNAME) return res.status(401).json({ error: 'Admin session expired. Please log in again.' });
    req.admin = claims;
    next();
  } catch { return res.status(401).json({ error: 'Invalid admin token.' }); }
}
