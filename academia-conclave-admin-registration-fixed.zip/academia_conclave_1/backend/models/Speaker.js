import mongoose from 'mongoose';

const speakerSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Speaker name is required'],
      trim: true,
      maxlength: [150, 'Name cannot exceed 150 characters']
    },
    designation: {
      type: String,
      trim: true,
      maxlength: [200, 'Designation cannot exceed 200 characters']
    },
    organization: {
      type: String,
      trim: true,
      maxlength: [200, 'Organization cannot exceed 200 characters']
    },
    biography: {
      type: String,
      trim: true,
      maxlength: [2000, 'Biography cannot exceed 2000 characters']
    },
    photo: {
      type: String,
      trim: true
    },
    sessionTitle: {
      type: String,
      trim: true,
      maxlength: [250, 'Session title cannot exceed 250 characters']
    },
    displayOrder: {
      type: Number,
      default: 0,
      index: true
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true
    }
  },
  {
    timestamps: true
  }
);

speakerSchema.index({ isActive: 1, displayOrder: 1 });

export const Speaker = mongoose.models.Speaker || mongoose.model('Speaker', speakerSchema);
export default Speaker;
