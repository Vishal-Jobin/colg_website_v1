import mongoose from 'mongoose';

const advisoryBoardSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Member name is required'],
      trim: true,
      maxlength: [150, 'Name cannot exceed 150 characters']
    },
    designation: {
      type: String,
      trim: true,
      maxlength: [250, 'Designation cannot exceed 250 characters']
    },
    organization: {
      type: String,
      trim: true,
      maxlength: [200, 'Organization cannot exceed 200 characters']
    },
    biography: {
      type: String,
      trim: true,
      maxlength: [2000, 'Biography cannot exceed 2000 characters']
    },
    photo: {
      type: String,
      trim: true
    },
    displayOrder: {
      type: Number,
      default: 0,
      index: true
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true
    }
  },
  {
    timestamps: true
  }
);

advisoryBoardSchema.index({ isActive: 1, displayOrder: 1 });

export const AdvisoryBoard = mongoose.models.AdvisoryBoard || mongoose.model('AdvisoryBoard', advisoryBoardSchema);
export default AdvisoryBoard;
