import mongoose from 'mongoose';

const registrationSchema = new mongoose.Schema(
  {
    fullName: {
      type: String,
      required: [true, 'Full name is required'],
      trim: true,
      minlength: [2, 'Full name must be at least 2 characters'],
      maxlength: [120, 'Full name cannot exceed 120 characters']
    },
    email: {
      type: String,
      required: [true, 'Email is required'],
      trim: true,
      lowercase: true,
      match: [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Please provide a valid email address'],
      maxlength: [150, 'Email cannot exceed 150 characters']
    },
    phone: {
      type: String,
      trim: true,
      maxlength: [25, 'Phone number cannot exceed 25 characters']
    },
    organization: {
      type: String,
      trim: true,
      maxlength: [200, 'Organization/Institution cannot exceed 200 characters']
    },
    designation: {
      type: String,
      trim: true,
      maxlength: [150, 'Designation cannot exceed 150 characters']
    },
    ticketType: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'TicketType',
      default: null
    },
    attendeeType: {
      type: String,
      trim: true,
      maxlength: [60, 'Attendee type cannot exceed 60 characters']
    },
    message: {
      type: String,
      trim: true,
      maxlength: [1000, 'Message cannot exceed 1000 characters']
    },
    status: {
      type: String,
      enum: ['pending', 'confirmed', 'cancelled'],
      default: 'pending'
    }
  },
  {
    timestamps: true
  }
);

registrationSchema.index({ createdAt: -1 });

export const Registration = mongoose.models.Registration || mongoose.model('Registration', registrationSchema);
export default Registration;
