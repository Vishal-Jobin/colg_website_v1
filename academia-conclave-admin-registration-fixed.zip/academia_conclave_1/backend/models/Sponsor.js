import mongoose from 'mongoose';

const sponsorSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Sponsor name is required'],
      trim: true,
      maxlength: [150, 'Name cannot exceed 150 characters']
    },
    logo: {
      type: String,
      trim: true
    },
    website: {
      type: String,
      trim: true
    },
    category: {
      type: String,
      trim: true,
      maxlength: [100, 'Category cannot exceed 100 characters'],
      default: 'Partner'
    },
    displayOrder: {
      type: Number,
      default: 0,
      index: true
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true
    }
  },
  {
    timestamps: true
  }
);

sponsorSchema.index({ isActive: 1, displayOrder: 1 });

export const Sponsor = mongoose.models.Sponsor || mongoose.model('Sponsor', sponsorSchema);
export default Sponsor;
