import mongoose from 'mongoose';

const scheduleItemSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Schedule title is required'],
      trim: true,
      maxlength: [200, 'Title cannot exceed 200 characters']
    },
    description: {
      type: String,
      trim: true,
      maxlength: [2000, 'Description cannot exceed 2000 characters']
    },
    day: {
      type: Number,
      required: [true, 'Day number is required'],
      min: 1,
      index: true
    },
    date: {
      type: Date
    },
    startTime: {
      type: String,
      trim: true
    },
    endTime: {
      type: String,
      trim: true
    },
    venue: {
      type: String,
      trim: true,
      maxlength: [150, 'Venue cannot exceed 150 characters']
    },
    speaker: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Speaker',
      default: null
    },
    displayOrder: {
      type: Number,
      default: 0,
      index: true
    }
  },
  {
    timestamps: true
  }
);

scheduleItemSchema.index({ day: 1, displayOrder: 1 });

export const ScheduleItem = mongoose.models.ScheduleItem || mongoose.model('ScheduleItem', scheduleItemSchema);
export default ScheduleItem;
