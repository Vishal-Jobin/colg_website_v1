import mongoose from 'mongoose';

const ticketTypeSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Ticket name is required'],
      trim: true,
      maxlength: [100, 'Ticket name cannot exceed 100 characters']
    },
    description: {
      type: String,
      trim: true,
      maxlength: [1000, 'Description cannot exceed 1000 characters']
    },
    price: {
      type: Number,
      required: [true, 'Price is required'],
      min: [0, 'Price must be non-negative']
    },
    currency: {
      type: String,
      default: 'INR',
      trim: true,
      maxlength: 10
    },
    benefits: {
      type: [String],
      default: []
    },
    availabilityStatus: {
      type: String,
      enum: ['available', 'limited', 'sold_out', 'upcoming'],
      default: 'available'
    },
    salesStartDate: {
      type: Date
    },
    salesEndDate: {
      type: Date
    },
    displayOrder: {
      type: Number,
      default: 0,
      index: true
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true
    }
  },
  {
    timestamps: true
  }
);

ticketTypeSchema.index({ isActive: 1, displayOrder: 1 });

export const TicketType = mongoose.models.TicketType || mongoose.model('TicketType', ticketTypeSchema);
export default TicketType;
