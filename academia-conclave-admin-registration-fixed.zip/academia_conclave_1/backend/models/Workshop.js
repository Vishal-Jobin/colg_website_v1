import mongoose from 'mongoose';

const workshopSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Workshop title is required'],
      trim: true,
      maxlength: [200, 'Title cannot exceed 200 characters']
    },
    description: {
      type: String,
      trim: true,
      maxlength: [3000, 'Description cannot exceed 3000 characters']
    },
    instructor: {
      type: String,
      trim: true,
      maxlength: [200, 'Instructor name cannot exceed 200 characters']
    },
    date: {
      type: Date
    },
    startTime: {
      type: String,
      trim: true
    },
    endTime: {
      type: String,
      trim: true
    },
    venue: {
      type: String,
      trim: true,
      maxlength: [200, 'Venue cannot exceed 200 characters']
    },
    image: {
      type: String,
      trim: true
    },
    registrationUrl: {
      type: String,
      trim: true
    },
    capacity: {
      type: Number,
      min: [0, 'Capacity cannot be negative']
    },
    displayOrder: {
      type: Number,
      default: 0,
      index: true
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true
    }
  },
  {
    timestamps: true
  }
);

workshopSchema.index({ isActive: 1, displayOrder: 1 });

export const Workshop = mongoose.models.Workshop || mongoose.model('Workshop', workshopSchema);
export default Workshop;
