import mongoose from 'mongoose';

const eventSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Event title is required'],
      trim: true,
      default: 'Confluence 3.0'
    },
    theme: {
      type: String,
      trim: true,
      default: 'India Impact Of AI'
    },
    description: {
      type: String,
      trim: true
    },
    venue: {
      type: String,
      trim: true,
      default: 'Rajagiri School of Engineering & Technology (Autonomous), Rajagiri Valley, Kakkanad, Kochi, Kerala 682039'
    },
    startDate: {
      type: Date
    },
    endDate: {
      type: Date
    },
    heroImage: {
      type: String,
      trim: true,
      default: '/images/new_front.png'
    },
    logo: {
      type: String,
      trim: true,
      default: '/images/rset_logo.png'
    },
    contactEmail: { type: String, trim: true, lowercase: true },
    contactPhone: { type: String, trim: true },
    contactAddress: { type: String, trim: true },
    registrationUrl: {
      type: String,
      trim: true,
      default: '/#/tickets'
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true
    }
  },
  {
    timestamps: true
  }
);

export const Event = mongoose.models.Event || mongoose.model('Event', eventSchema);
export default Event;
