import { Speaker } from '../models/Speaker.js';
import { AdvisoryBoard } from '../models/AdvisoryBoard.js';
import { Workshop } from '../models/Workshop.js';
import { Sponsor } from '../models/Sponsor.js';
import { TicketType } from '../models/TicketType.js';
import { Event } from '../models/Event.js';
import { Registration } from '../models/Registration.js';

const collections = {
  speakers: Speaker,
  'advisory-board': AdvisoryBoard,
  workshops: Workshop,
  sponsors: Sponsor,
  tickets: TicketType
};
const allowedEventFields = ['title', 'theme', 'description', 'venue', 'startDate', 'endDate', 'heroImage', 'logo', 'registrationUrl', 'contactEmail', 'contactPhone', 'contactAddress'];

export async function adminList(req, res, next) {
  try {
    const key = req.params.collection;
    if (key === 'registrations') {
      const rows = await Registration.find().populate('ticketType', 'name price currency').sort({ createdAt: -1 }).lean();
      return res.json({ data: rows });
    }
    if (key === 'contact') {
      const event = await Event.findOne({ isActive: true }).lean();
      return res.json({ data: event || {} });
    }
    const Model = collections[key];
    if (!Model) return res.status(404).json({ error: 'Unknown content section.' });
    res.json({ data: await Model.find().sort({ displayOrder: 1, createdAt: -1 }).lean() });
  } catch (err) { next(err); }
}

export async function adminCreate(req, res, next) {
  try {
    const Model = collections[req.params.collection];
    if (!Model) return res.status(404).json({ error: 'Unknown content section.' });
    const item = await Model.create(req.body);
    res.status(201).json({ data: item, message: 'Content added successfully.' });
  } catch (err) { next(err); }
}

export async function adminUpdate(req, res, next) {
  try {
    if (req.params.collection === 'registrations') {
      const status = req.body.status;
      if (!['pending', 'confirmed', 'cancelled'].includes(status)) return res.status(400).json({ error: 'Choose pending, confirmed, or cancelled.' });
      const registration = await Registration.findByIdAndUpdate(req.params.id, { $set: { status } }, { new: true, runValidators: true }).populate('ticketType', 'name price currency');
      if (!registration) return res.status(404).json({ error: 'Registration not found.' });
      return res.json({ data: registration, message: 'Registration status updated.' });
    }
    if (req.params.collection === 'contact') {
      const patch = {};
      for (const key of allowedEventFields) if (req.body[key] !== undefined) patch[key] = req.body[key];
      let event = await Event.findOneAndUpdate({ isActive: true }, { $set: patch }, { new: true, runValidators: true });
      if (!event) event = await Event.create({ ...patch, isActive: true });
      return res.json({ data: event, message: 'Contact and event details updated.' });
    }
    const Model = collections[req.params.collection];
    if (!Model) return res.status(404).json({ error: 'Unknown content section.' });
    const item = await Model.findByIdAndUpdate(req.params.id, { $set: req.body }, { new: true, runValidators: true });
    if (!item) return res.status(404).json({ error: 'Content not found.' });
    res.json({ data: item, message: 'Content updated successfully.' });
  } catch (err) { next(err); }
}

export async function adminDelete(req, res, next) {
  try {
    if (req.params.collection === 'registrations') {
      const item = await Registration.findByIdAndDelete(req.params.id);
      if (!item) return res.status(404).json({ error: 'Registration not found.' });
      return res.json({ message: 'Registration deleted.' });
    }
    const Model = collections[req.params.collection];
    if (!Model) return res.status(404).json({ error: 'Unknown content section.' });
    const item = await Model.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).json({ error: 'Content not found.' });
    res.json({ message: 'Content deleted successfully.' });
  } catch (err) { next(err); }
}
