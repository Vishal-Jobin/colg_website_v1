import { ContactMessage } from '../models/ContactMessage.js';

export const createContactMessage = async (req, res, next) => {
  try {
    const { name, email, subject, message } = req.body;

    const trimmedName = (name || '').trim();
    const trimmedEmail = (email || '').trim().toLowerCase();
    const trimmedSubject = (subject || 'General Inquiry').trim();
    const trimmedMessage = (message || '').trim();

    if (!trimmedName || trimmedName.length < 2) {
      return res.status(400).json({
        success: false,
        error: 'Please enter your full name (minimum 2 characters).'
      });
    }

    if (!trimmedEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      return res.status(400).json({
        success: false,
        error: 'Please enter a valid email address.'
      });
    }

    if (!trimmedMessage || trimmedMessage.length < 10) {
      return res.status(400).json({
        success: false,
        error: 'Your message should be at least 10 characters long.'
      });
    }

    const contactEntry = await ContactMessage.create({
      name: trimmedName,
      email: trimmedEmail,
      subject: trimmedSubject,
      message: trimmedMessage,
      status: 'unread'
    });

    res.status(201).json({
      success: true,
      message: 'Thank you! Your message has been received by the Confluence 3.0 team.',
      data: {
        id: contactEntry._id,
        createdAt: contactEntry.createdAt
      }
    });
  } catch (error) {
    next(error);
  }
};
