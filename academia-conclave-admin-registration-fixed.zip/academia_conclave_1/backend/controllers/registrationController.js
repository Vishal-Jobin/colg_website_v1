import mongoose from 'mongoose';
import { Registration } from '../models/Registration.js';
import { TicketType } from '../models/TicketType.js';

export const createRegistration = async (req, res, next) => {
  try {
    const {
      name,
      fullName,
      email,
      phone,
      organization,
      institution,
      designation,
      ticketType,
      ticketTypeId,
      passType,
      attendeeType,
      message
    } = req.body;

    const normalizedName = (fullName || name || '').trim();
    const normalizedEmail = (email || '').trim().toLowerCase();
    const normalizedOrg = (organization || institution || '').trim();
    const normalizedAttendee = (attendeeType || passType || '').trim();

    if (!normalizedName) {
      return res.status(400).json({
        success: false,
        error: 'Full name is required.'
      });
    }

    if (!normalizedEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
      return res.status(400).json({
        success: false,
        error: 'Please provide a valid email address.'
      });
    }

    let validTicketTypeId = null;
    const ticketCandidate = ticketType || ticketTypeId;

    if (ticketCandidate) {
      if (mongoose.Types.ObjectId.isValid(ticketCandidate)) {
        const ticketExists = await TicketType.findById(ticketCandidate);
        if (!ticketExists) {
          return res.status(400).json({
            success: false,
            error: 'Referenced ticket type does not exist.'
          });
        }
        validTicketTypeId = ticketExists._id;
      } else {
        // Find ticket by slug or name if string passed
        const foundTicket = await TicketType.findOne({
          $or: [
            { name: new RegExp(`^${ticketCandidate}$`, 'i') },
            { name: new RegExp(ticketCandidate, 'i') }
          ]
        });
        if (foundTicket) {
          validTicketTypeId = foundTicket._id;
        }
      }
    }

    const registration = await Registration.create({
      fullName: normalizedName,
      email: normalizedEmail,
      phone: (phone || '').trim(),
      organization: normalizedOrg,
      designation: (designation || '').trim(),
      ticketType: validTicketTypeId,
      attendeeType: normalizedAttendee,
      message: (message || '').trim(),
      status: 'pending'
    });

    res.status(201).json({
      success: true,
      message: 'Registration submitted successfully.',
      data: {
        id: registration._id,
        fullName: registration.fullName,
        email: registration.email,
        attendeeType: registration.attendeeType,
        status: registration.status,
        createdAt: registration.createdAt
      }
    });
  } catch (error) {
    next(error);
  }
};
