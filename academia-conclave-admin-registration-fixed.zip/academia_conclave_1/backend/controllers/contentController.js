import { Speaker } from '../models/Speaker.js';
import { AdvisoryBoard } from '../models/AdvisoryBoard.js';
import { Workshop } from '../models/Workshop.js';
import { Sponsor } from '../models/Sponsor.js';
import { ScheduleItem } from '../models/ScheduleItem.js';
import { TicketType } from '../models/TicketType.js';
import { Event } from '../models/Event.js';

export const getSpeakers = async (req, res, next) => {
  try {
    const speakers = await Speaker.find({ isActive: true })
      .sort({ displayOrder: 1, createdAt: 1 })
      .lean();
    res.json({
      success: true,
      count: speakers.length,
      data: speakers
    });
  } catch (error) {
    next(error);
  }
};

export const getAdvisoryBoard = async (req, res, next) => {
  try {
    const advisoryBoard = await AdvisoryBoard.find({ isActive: true })
      .sort({ displayOrder: 1, createdAt: 1 })
      .lean();
    res.json({
      success: true,
      count: advisoryBoard.length,
      data: advisoryBoard
    });
  } catch (error) {
    next(error);
  }
};

export const getWorkshops = async (req, res, next) => {
  try {
    const workshops = await Workshop.find({ isActive: true })
      .sort({ displayOrder: 1, createdAt: 1 })
      .lean();
    res.json({
      success: true,
      count: workshops.length,
      data: workshops
    });
  } catch (error) {
    next(error);
  }
};

export const getSponsors = async (req, res, next) => {
  try {
    const sponsors = await Sponsor.find({ isActive: true })
      .sort({ displayOrder: 1, createdAt: 1 })
      .lean();
    res.json({
      success: true,
      count: sponsors.length,
      data: sponsors
    });
  } catch (error) {
    next(error);
  }
};

export const getSchedule = async (req, res, next) => {
  try {
    const { day } = req.query;
    const filter = {};
    if (day) {
      filter.day = Number(day);
    }

    const schedule = await ScheduleItem.find(filter)
      .populate('speaker', 'name designation organization photo')
      .sort({ day: 1, displayOrder: 1, createdAt: 1 })
      .lean();

    res.json({
      success: true,
      count: schedule.length,
      data: schedule
    });
  } catch (error) {
    next(error);
  }
};

export const getTickets = async (req, res, next) => {
  try {
    const tickets = await TicketType.find({ isActive: true })
      .sort({ displayOrder: 1, price: 1 })
      .lean();
    res.json({
      success: true,
      count: tickets.length,
      data: tickets
    });
  } catch (error) {
    next(error);
  }
};

export const getEvent = async (req, res, next) => {
  try {
    const event = await Event.findOne({ isActive: true }).lean();
    res.json({
      success: true,
      data: event || {
        title: 'Confluence 3.0',
        theme: 'India Impact Of AI',
        venue: 'Rajagiri School of Engineering & Technology (Autonomous)',
        isActive: true
      }
    });
  } catch (error) {
    next(error);
  }
};
