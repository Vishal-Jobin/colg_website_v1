import express from 'express';
import {
  getSpeakers,
  getAdvisoryBoard,
  getWorkshops,
  getSponsors,
  getSchedule,
  getTickets,
  getEvent
} from '../controllers/contentController.js';
import { createRegistration } from '../controllers/registrationController.js';
import { createContactMessage } from '../controllers/contactController.js';
import { checkDBConnection } from '../middleware/common.js';
import { submissionLimiter } from '../middleware/rateLimiter.js';
import { getDBStatus } from '../config/db.js';
import { adminLogin, requireAdmin } from '../middleware/adminAuth.js';
import { adminList, adminCreate, adminUpdate, adminDelete } from '../controllers/adminController.js';

const router = express.Router();

// Health check (always available, indicates DB readiness)
router.get('/health', (req, res) => {
  const dbStatus = getDBStatus();
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    service: 'Confluence 3.0 API',
    database: {
      connected: dbStatus.connected,
      status: dbStatus.status
    }
  });
});

// Admin authentication and protected content management
router.post('/admin/login', adminLogin);
router.get('/admin/:collection', requireAdmin, checkDBConnection, adminList);
router.post('/admin/:collection', requireAdmin, checkDBConnection, adminCreate);
router.put('/admin/:collection/:id', requireAdmin, checkDBConnection, adminUpdate);
router.delete('/admin/:collection/:id', requireAdmin, checkDBConnection, adminDelete);

// Public content endpoints (require active DB)
router.get('/speakers', checkDBConnection, getSpeakers);
router.get('/advisory-board', checkDBConnection, getAdvisoryBoard);
router.get('/workshops', checkDBConnection, getWorkshops);
router.get('/sponsors', checkDBConnection, getSponsors);
router.get('/schedule', checkDBConnection, getSchedule);
router.get('/tickets', checkDBConnection, getTickets);
router.get('/event', checkDBConnection, getEvent);

// Public submission endpoints (with rate limiting, validation, and DB check)
router.post('/registrations', checkDBConnection, submissionLimiter, createRegistration);
router.post('/contact', checkDBConnection, submissionLimiter, createContactMessage);

export default router;
