import express from 'express';
import cors from 'cors';
import apiRoutes from './routes/api.js';
import { errorHandler } from './middleware/common.js';

const app = express();

const clientUrl = process.env.CLIENT_URL || 'http://localhost:5173';

// CORS configuration restricted to configured client origin
app.use(
  cors({
    origin: (origin, callback) => {
      // allow requests with no origin (like mobile apps, curl, postman) or matching origin
      if (!origin || origin === clientUrl || origin.startsWith('http://localhost:')) {
        callback(null, true);
      } else {
        callback(new Error('Blocked by CORS policy'));
      }
    },
    credentials: true
  })
);

// Body parsing with sensible size limits
app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: true, limit: '100kb' }));

// Mount all API routes under /api
app.use('/api', apiRoutes);

// Centralized error handler
app.use(errorHandler);

export default app;
