import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import app from './app.js';
import { connectDB } from './config/db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables from backend/.env or root .env
dotenv.config({ path: path.resolve(__dirname, '../.env') });
dotenv.config(); // Fallback to current working directory .env if present

const PORT = process.env.PORT || 5000;

async function startServer() {
  try {
    // Connect to MongoDB before starting to accept requests requiring DB access
    await connectDB();
    console.log('[Database] MongoDB connection established successfully.');
  } catch (err) {
    console.error('[Database Warning] Starting server without active MongoDB connection:', err.message);
  }

  app.listen(PORT, () => {
    console.log(`[Confluence 3.0 API] Server running on http://localhost:${PORT}`);
    console.log(`[Confluence 3.0 API] Health check at http://localhost:${PORT}/api/health`);
  });
}

startServer();
