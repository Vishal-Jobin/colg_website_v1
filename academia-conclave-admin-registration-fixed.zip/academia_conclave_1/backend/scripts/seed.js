import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import { connectDB } from '../config/db.js';
import { Speaker } from '../models/Speaker.js';
import { AdvisoryBoard } from '../models/AdvisoryBoard.js';
import { Workshop } from '../models/Workshop.js';
import { Sponsor } from '../models/Sponsor.js';
import { ScheduleItem } from '../models/ScheduleItem.js';
import { TicketType } from '../models/TicketType.js';
import { Event } from '../models/Event.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config({ path: path.resolve(__dirname, '../../.env') });
dotenv.config();

const dataJsonPath = path.resolve(__dirname, '../../frontend/src/data.json');

async function seed() {
  console.log('[Seed] Connecting to MongoDB...');
  await connectDB();

  if (!fs.existsSync(dataJsonPath)) {
    throw new Error(`Data file not found at ${dataJsonPath}`);
  }

  const rawData = fs.readFileSync(dataJsonPath, 'utf-8');
  const seedData = JSON.parse(rawData);

  console.log('[Seed] Seeding Event metadata...');
  await Event.findOneAndUpdate(
    { title: 'Confluence 3.0' },
    {
      title: 'Confluence 3.0',
      theme: 'India Impact Of AI',
      description: 'The largest industry-academia summit organized by Rajagiri School of Engineering & Technology.',
      venue: seedData.contactInfo?.address || 'Rajagiri School of Engineering & Technology (Autonomous), Kochi, Kerala',
      startDate: new Date('2026-08-31T16:00:00+05:30'),
      endDate: new Date('2026-09-01T17:00:00+05:30'),
      heroImage: '/images/new_front.png',
      logo: '/images/rset_logo.png',
      registrationUrl: '/#/tickets',
      isActive: true
    },
    { upsert: true, new: true }
  );

  console.log('[Seed] Seeding Speakers...');
  const speakerMap = new Map();
  if (Array.isArray(seedData.speakers)) {
    for (let i = 0; i < seedData.speakers.length; i++) {
      const sp = seedData.speakers[i];
      const titleStr = Array.isArray(sp.title) ? sp.title.join(' | ') : (sp.title || '');
      const doc = await Speaker.findOneAndUpdate(
        { name: sp.name.trim() },
        {
          name: sp.name.trim(),
          designation: titleStr,
          organization: '',
          biography: '',
          photo: sp.image || '',
          sessionTitle: '',
          displayOrder: i + 1,
          isActive: true
        },
        { upsert: true, new: true }
      );
      speakerMap.set(sp.name.trim().toLowerCase(), doc._id);
    }
  }

  console.log('[Seed] Seeding Advisory Board...');
  if (Array.isArray(seedData.advisoryBoard)) {
    let orderCounter = 1;
    for (const group of seedData.advisoryBoard) {
      if (Array.isArray(group.members)) {
        for (const member of group.members) {
          await AdvisoryBoard.findOneAndUpdate(
            { name: member.name.trim() },
            {
              name: member.name.trim(),
              designation: member.designation || group.title || '',
              organization: member.organization || 'RSET',
              biography: '',
              photo: member.imageUrl || '',
              displayOrder: orderCounter++,
              isActive: true
            },
            { upsert: true, new: true }
          );
        }
      }
    }
  }

  console.log('[Seed] Seeding Workshops...');
  if (Array.isArray(seedData.workshops)) {
    for (let i = 0; i < seedData.workshops.length; i++) {
      const ws = seedData.workshops[i];
      const instructorStr = ws.resourcePerson ||
        (Array.isArray(ws.resourcePersons) ? ws.resourcePersons.map(p => `${p.name} (${p.designation})`).join(', ') : '');
      const [startTime, endTime] = ws.time ? ws.time.split(' to ') : ['', ''];

      await Workshop.findOneAndUpdate(
        { title: ws.title.trim() },
        {
          title: ws.title.trim(),
          description: ws.block ? `Block: ${ws.block}` : '',
          instructor: instructorStr,
          date: new Date('2026-09-01T14:00:00+05:30'),
          startTime: (startTime || '2:00 PM').trim(),
          endTime: (endTime || '4:00 PM').trim(),
          venue: ws.venue || '',
          image: ws.image || '',
          registrationUrl: ws.registrationLink || '',
          capacity: 50,
          displayOrder: i + 1,
          isActive: true
        },
        { upsert: true, new: true }
      );
    }
  }

  console.log('[Seed] Seeding Sponsors & Partners...');
  if (Array.isArray(seedData.sponsors)) {
    let sponsorOrder = 1;
    for (const category of seedData.sponsors) {
      if (Array.isArray(category.members)) {
        for (const sp of category.members) {
          await Sponsor.findOneAndUpdate(
            { name: sp.name.trim(), category: category.title },
            {
              name: sp.name.trim(),
              logo: sp.logo || '',
              website: sp.url || '',
              category: category.title || 'Partner',
              displayOrder: sponsorOrder++,
              isActive: true
            },
            { upsert: true, new: true }
          );
        }
      }
    }
  }

  console.log('[Seed] Seeding Ticket Types...');
  if (Array.isArray(seedData.tickets)) {
    for (let i = 0; i < seedData.tickets.length; i++) {
      const t = seedData.tickets[i];
      let price = 0;
      if (t.id === 'business') price = 400;
      if (t.id === 'academic') price = 300;
      if (t.id === 'young') price = 200;

      const benefits = Array.isArray(t.features)
        ? t.features.filter(f => f.included).map(f => f.text)
        : [];

      await TicketType.findOneAndUpdate(
        { name: t.title.trim() },
        {
          name: t.title.trim(),
          description: t.forText || '',
          price: price,
          currency: 'INR',
          benefits: benefits,
          availabilityStatus: 'available',
          displayOrder: i + 1,
          isActive: true
        },
        { upsert: true, new: true }
      );
    }
  }

  console.log('[Seed] Seeding Schedule Items (Day 1 & Day 2)...');
  const seedScheduleDay = async (items, dayNum, defaultDate) => {
    if (!Array.isArray(items)) return;
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      let matchedSpeakerId = null;

      // Link speaker if subtitle or title matches any known speaker name
      for (const [name, id] of speakerMap.entries()) {
        if ((item.subtitle && item.subtitle.toLowerCase().includes(name)) ||
            (item.title && item.title.toLowerCase().includes(name))) {
          matchedSpeakerId = id;
          break;
        }
      }

      await ScheduleItem.findOneAndUpdate(
        { title: item.title.trim(), day: dayNum, startTime: item.time },
        {
          title: item.title.trim(),
          description: item.subtitle || (item.type ? `Type: ${item.type}` : ''),
          day: dayNum,
          date: new Date(defaultDate),
          startTime: item.time || '',
          endTime: '',
          venue: 'Main Auditorium, RSET',
          speaker: matchedSpeakerId,
          displayOrder: i + 1
        },
        { upsert: true, new: true }
      );
    }
  };

  await seedScheduleDay(seedData.scheduleDay1, 1, '2026-08-31');
  await seedScheduleDay(seedData.scheduleDay2, 2, '2026-09-01');

  console.log('✅ [Seed Completed Successfully]');
  await mongoose.disconnect();
}

seed().catch(err => {
  console.error('❌ [Seed Failed]:', err);
  process.exit(1);
});
