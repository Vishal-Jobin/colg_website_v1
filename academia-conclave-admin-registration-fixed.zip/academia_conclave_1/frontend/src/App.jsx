import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { Workshops } from './pages/Workshops';
import { AdvisoryBoard } from './pages/AdvisoryBoard';
import { Speakers } from './pages/Speakers';
import { SponsorsPartners } from './pages/SponsorsPartners';
import { Tickets } from './pages/Tickets';
import { Contact } from './pages/Contact';
import { ScheduleDay } from './pages/ScheduleDay';
import { Venue } from './pages/Venue';
import { Admin } from './pages/Admin';

export function App() {
  const { pathname } = useLocation();
  // Keep /admin available as a clean URL even while the public site uses HashRouter.
  const isAdminPath = pathname.replace(/\/$/, '') === '/admin' || window.location.pathname.replace(/\/$/, '') === '/admin';

  useEffect(() => {
    if (!isAdminPath) window.scrollTo(0, 0);
  }, [pathname, isAdminPath]);

  if (isAdminPath) return <Admin />;

  return (
    <div className="min-h-screen bg-paper-50 font-sans text-slate-900 antialiased app-container">
      <Navbar />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/workshops" element={<Workshops />} />
          <Route path="/advisory-board" element={<AdvisoryBoard />} />
          <Route path="/speakers" element={<Speakers />} />
          <Route path="/sponsors-partners" element={<SponsorsPartners />} />
          <Route path="/sponsors" element={<SponsorsPartners />} />
          <Route path="/tickets" element={<Tickets />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/day1" element={<ScheduleDay dayNumber={1} />} />
          <Route path="/day2" element={<ScheduleDay dayNumber={2} />} />
          <Route path="/venue" element={<Venue />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="*" element={<Home />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default App;
