const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

async function request(endpoint, options = {}) {
  const url = `${API_BASE_URL}${endpoint}`;
  const config = {
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    },
    ...options
  };

  try {
    const res = await fetch(url, config);
    let data;
    try {
      data = await res.json();
    } catch {
      data = null;
    }

    if (!res.ok) {
      const errorMessage =
        (data && data.error) ||
        (data && data.message) ||
        `Request failed with status ${res.status}: ${res.statusText}`;
      const error = new Error(errorMessage);
      error.status = res.status;
      error.data = data;
      throw error;
    }

    return data;
  } catch (err) {
    // If it's a network disconnect / fetch error
    if (!err.status) {
      const networkError = new Error('Unable to connect to server. Please ensure the backend is running.');
      networkError.isNetworkError = true;
      throw networkError;
    }
    throw err;
  }
}

export const api = {
  // Public content
  getHealth: () => request('/health'),
  getEvent: () => request('/event'),
  getSpeakers: () => request('/speakers'),
  getAdvisoryBoard: () => request('/advisory-board'),
  getWorkshops: () => request('/workshops'),
  getSponsors: () => request('/sponsors'),
  getSchedule: (day) => request(day ? `/schedule?day=${day}` : '/schedule'),
  getTickets: () => request('/tickets'),

  // Form Submissions
  submitRegistration: (payload) =>
    request('/registrations', {
      method: 'POST',
      body: JSON.stringify(payload)
    }),

  submitContact: (payload) =>
    request('/contact', {
      method: 'POST',
      body: JSON.stringify(payload)
    })
};

export default api;
