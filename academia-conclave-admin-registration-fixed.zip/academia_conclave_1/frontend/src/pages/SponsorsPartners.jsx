import React, { useState, useEffect } from 'react';
import { Loader2, AlertCircle } from 'lucide-react';
import api from '../services/api';
import localData from '../data.json';

export const SponsorsPartners = () => {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let isMounted = true;
    const fetchSponsors = async () => {
      try {
        setLoading(true);
        const res = await api.getSponsors();
        if (isMounted) {
          if (res.data && res.data.length > 0) {
            // Group by category to retain presentation
            const map = new Map();
            res.data.forEach((s) => {
              const catName = s.category || 'Partners';
              if (!map.has(catName)) {
                map.set(catName, {
                  id: catName.toLowerCase().replace(/\s+/g, '-'),
                  title: catName,
                  members: []
                });
              }
              map.get(catName).members.push({
                name: s.name,
                logo: s.logo,
                url: s.website,
                tagline: s.category
              });
            });
            setCategories(Array.from(map.values()));
          } else {
            setCategories([]);
          }
          setError(null);
        }
      } catch (err) {
        console.warn('Could not fetch sponsors from API, falling back to local dataset:', err.message);
        if (isMounted) {
          setCategories(localData.sponsors || []);
          setError('Backend offline: Displaying cached sponsors.');
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    fetchSponsors();
    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <div className="sponsors-page">
      <section className="ws-hero">
        <div className="ws-hero__content">
          <p className="ws-hero__eyebrow">Confluence 3.0</p>
          <h1 className="ws-hero__title">Sponsors & Partners</h1>
          <p className="ws-hero__text">
            Proudly supported by leading industry partners driving innovation and excellence in engineering and technology education.
          </p>
        </div>
      </section>

      <div style={{ maxWidth: '1200px', margin: '3.5rem auto', padding: '0 1.5rem' }}>
        {loading && (
          <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '4rem 0', gap: '0.75rem', color: '#0A2540' }}>
            <Loader2 className="animate-spin" size={28} />
            <span style={{ fontSize: '1.1rem', fontWeight: 600 }}>Loading sponsors & partners...</span>
          </div>
        )}

        {error && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', backgroundColor: '#eff6ff', color: '#1e40af', padding: '0.75rem 1rem', borderRadius: '8px', marginBottom: '2rem', fontSize: '0.9rem' }}>
            <AlertCircle size={18} />
            <span>{error}</span>
          </div>
        )}

        {!loading && categories.length === 0 && (
          <div style={{ textAlign: 'center', padding: '4rem 0', color: '#64748b' }}>
            <p style={{ fontSize: '1.1rem', fontWeight: 600 }}>No sponsor listings available at this time.</p>
          </div>
        )}

        {!loading && categories.map((category) => (
          <div key={category.id || category.title} style={{ marginBottom: '4rem', textAlign: 'center' }}>
            <h2 style={{ fontSize: '1.6rem', fontWeight: 800, color: '#0A2540', marginBottom: '0.5rem' }}>
              {category.title}
            </h2>
            <div style={{ width: '50px', height: '3px', backgroundColor: '#d4af37', margin: '0 auto 2rem' }} />

            <div
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                justifyContent: 'center',
                alignItems: 'center',
                gap: '2rem'
              }}
            >
              {category.members.map((sponsor, sIdx) => (
                <div
                  key={sIdx}
                  style={{
                    backgroundColor: '#ffffff',
                    border: '1px solid #e2e8f0',
                    borderRadius: '12px',
                    padding: '1.5rem 2rem',
                    minWidth: '220px',
                    maxWidth: '320px',
                    minHeight: '110px',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.03)'
                  }}
                >
                  {sponsor.logo ? (
                    <img
                      src={sponsor.logo}
                      alt={sponsor.name}
                      style={{ maxHeight: '60px', maxWidth: '180px', objectFit: 'contain' }}
                      onError={(e) => {
                        e.target.style.display = 'none';
                        if (e.target.nextSibling) {
                          e.target.nextSibling.style.display = 'block';
                        }
                      }}
                    />
                  ) : null}
                  <span
                    style={{
                      display: sponsor.logo ? 'none' : 'block',
                      fontWeight: 700,
                      color: '#0A2540',
                      fontSize: '1.1rem'
                    }}
                  >
                    {sponsor.name}
                  </span>
                  {sponsor.tagline && (
                    <span style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.25rem' }}>
                      {sponsor.tagline}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
export default SponsorsPartners;
