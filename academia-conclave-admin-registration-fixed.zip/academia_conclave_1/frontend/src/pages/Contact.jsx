import React, { useEffect, useState } from 'react';
import { Mail, Phone, MapPin, Send, CheckCircle2, AlertCircle } from 'lucide-react';
import data from '../data.json';

import api from '../services/api';

export const Contact = () => {
  const [eventInfo, setEventInfo] = useState(null);
  useEffect(() => { api.getEvent().then(r => setEventInfo(r.data || null)).catch(() => {}); }, []);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: data.contactTopics[0] || '',
    message: ''
  });
  const [status, setStatus] = useState({ loading: false, error: null, success: null });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    if (status.error) setStatus({ ...status, error: null });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.name.trim()) {
      setStatus({ loading: false, error: 'Please enter your full name.', success: null });
      return;
    }
    if (!formData.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      setStatus({ loading: false, error: 'Please enter a valid email address.', success: null });
      return;
    }
    if (!formData.message.trim() || formData.message.trim().length < 10) {
      setStatus({ loading: false, error: 'Your message should be at least 10 characters long.', success: null });
      return;
    }

    setStatus({ loading: true, error: null, success: null });
    try {
      const resData = await api.submitContact(formData);

      setStatus({
        loading: false,
        error: null,
        success: resData.message || 'Thank you! Your message has been received by the Confluence 3.0 team.'
      });
      setFormData({
        name: '',
        email: '',
        subject: data.contactTopics[0] || '',
        message: ''
      });
    } catch (err) {
      setStatus({
        loading: false,
        error: err.message || 'Failed to send message',
        success: null
      });
    }
  };

  return (
    <div className="contact-page">
      <section className="contact-hero">
        <div aria-hidden="true" className="contact-hero__grid" />
        <div aria-hidden="true" className="contact-hero__glow" />
        <div className="contact-hero__content">
          <h1 className="contact-hero__title">
            Contact the <span className="contact-hero__title-accent">Confluence 3.0</span> team
          </h1>
          <p className="contact-hero__text">
            Questions about workshops, speakers, or campus access? Registration, sponsorship, or press — the organising team is ready to help.
          </p>
        </div>
      </section>

      {/* Info Cards */}
      <section className="contact-cards" style={{ maxWidth: '1200px', margin: '3rem auto 0', padding: '0 1.5rem' }}>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
            gap: '1.5rem',
            marginBottom: '3rem'
          }}
        >
          <div
            style={{
              backgroundColor: '#fff',
              border: '1px solid #e2e8f0',
              borderRadius: '12px',
              padding: '1.75rem',
              display: 'flex',
              alignItems: 'flex-start',
              gap: '1rem',
              boxShadow: '0 4px 12px rgba(0,0,0,0.03)'
            }}
          >
            <Mail size={24} color="#0A2540" style={{ marginTop: '0.2rem' }} />
            <div>
              <h3 style={{ fontSize: '1rem', fontWeight: 700, color: '#0f172a' }}>Email Us</h3>
              <p style={{ fontSize: '0.88rem', color: '#64748b', marginTop: '0.2rem' }}>
                {eventInfo?.contactEmail || data.contactInfo.email}
              </p>
            </div>
          </div>

          <div
            style={{
              backgroundColor: '#fff',
              border: '1px solid #e2e8f0',
              borderRadius: '12px',
              padding: '1.75rem',
              display: 'flex',
              alignItems: 'flex-start',
              gap: '1rem',
              boxShadow: '0 4px 12px rgba(0,0,0,0.03)'
            }}
          >
            <Phone size={24} color="#0A2540" style={{ marginTop: '0.2rem' }} />
            <div>
              <h3 style={{ fontSize: '1rem', fontWeight: 700, color: '#0f172a' }}>Phone Support</h3>
              <p style={{ fontSize: '0.88rem', color: '#64748b', marginTop: '0.2rem' }}>
                {eventInfo?.contactPhone || data.contactInfo.phone}
              </p>
            </div>
          </div>

          <div
            style={{
              backgroundColor: '#fff',
              border: '1px solid #e2e8f0',
              borderRadius: '12px',
              padding: '1.75rem',
              display: 'flex',
              alignItems: 'flex-start',
              gap: '1rem',
              boxShadow: '0 4px 12px rgba(0,0,0,0.03)'
            }}
          >
            <MapPin size={24} color="#0A2540" style={{ marginTop: '0.2rem' }} />
            <div>
              <h3 style={{ fontSize: '1rem', fontWeight: 700, color: '#0f172a' }}>Venue & Campus</h3>
              <p style={{ fontSize: '0.85rem', color: '#64748b', marginTop: '0.2rem', lineHeight: 1.4 }}>
                {eventInfo?.contactAddress || eventInfo?.venue || data.contactInfo.address}
              </p>
            </div>
          </div>
        </div>

        {/* Contact Form */}
        <div
          style={{
            maxWidth: '700px',
            margin: '0 auto 4rem',
            backgroundColor: '#fff',
            border: '1px solid #e2e8f0',
            borderRadius: '16px',
            padding: '2.5rem',
            boxShadow: '0 4px 20px rgba(0,0,0,0.05)'
          }}
        >
          <h2 style={{ fontSize: '1.5rem', fontWeight: 800, color: '#0A2540', marginBottom: '1.5rem', textAlign: 'center' }}>
            Send Us a Message
          </h2>

          {status.error && (
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.6rem',
                backgroundColor: '#fef2f2',
                color: '#dc2626',
                padding: '1rem',
                borderRadius: '8px',
                marginBottom: '1.5rem',
                fontSize: '0.9rem'
              }}
            >
              <AlertCircle size={20} />
              <span>{status.error}</span>
            </div>
          )}

          {status.success && (
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.6rem',
                backgroundColor: '#f0fdf4',
                color: '#16a34a',
                padding: '1rem',
                borderRadius: '8px',
                marginBottom: '1.5rem',
                fontSize: '0.9rem'
              }}
            >
              <CheckCircle2 size={20} />
              <span>{status.success}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, color: '#334155', marginBottom: '0.35rem' }}>
                Your Name *
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                placeholder="Full name"
                style={{
                  width: '100%',
                  padding: '0.75rem 1rem',
                  borderRadius: '8px',
                  border: '1px solid #cbd5e1',
                  fontSize: '0.95rem'
                }}
              />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, color: '#334155', marginBottom: '0.35rem' }}>
                Email Address *
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                placeholder="your.email@example.com"
                style={{
                  width: '100%',
                  padding: '0.75rem 1rem',
                  borderRadius: '8px',
                  border: '1px solid #cbd5e1',
                  fontSize: '0.95rem'
                }}
              />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, color: '#334155', marginBottom: '0.35rem' }}>
                Subject / Topic *
              </label>
              <select
                name="subject"
                value={formData.subject}
                onChange={handleChange}
                style={{
                  width: '100%',
                  padding: '0.75rem 1rem',
                  borderRadius: '8px',
                  border: '1px solid #cbd5e1',
                  fontSize: '0.95rem',
                  backgroundColor: '#fff'
                }}
              >
                {data.contactTopics.map((topic, idx) => (
                  <option key={idx} value={topic}>
                    {topic}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, color: '#334155', marginBottom: '0.35rem' }}>
                Message *
              </label>
              <textarea
                name="message"
                value={formData.message}
                onChange={handleChange}
                rows={5}
                required
                placeholder="How can we help you regarding Confluence 3.0?"
                style={{
                  width: '100%',
                  padding: '0.75rem 1rem',
                  borderRadius: '8px',
                  border: '1px solid #cbd5e1',
                  fontSize: '0.95rem',
                  resize: 'vertical'
                }}
              />
            </div>

            <button
              type="submit"
              disabled={status.loading}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.5rem',
                backgroundColor: '#0A2540',
                color: '#ffffff',
                border: 'none',
                padding: '1rem',
                borderRadius: '8px',
                fontSize: '1rem',
                fontWeight: 700,
                cursor: status.loading ? 'not-allowed' : 'pointer',
                marginTop: '0.5rem',
                boxShadow: '0 4px 12px rgba(10, 37, 64, 0.2)'
              }}
            >
              <Send size={18} />
              {status.loading ? 'Sending message...' : 'Send Message'}
            </button>
          </form>
        </div>
      </section>
    </div>
  );
};
