import React, { useState, useEffect } from 'react';
import { ExternalLink, User, Loader2, AlertCircle } from 'lucide-react';
import api from '../services/api';
import localData from '../data.json';

export const Speakers = () => {
  const [speakers, setSpeakers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let isMounted = true;
    const fetchSpeakers = async () => {
      try {
        setLoading(true);
        const res = await api.getSpeakers();
        if (isMounted) {
          if (res.data && res.data.length > 0) {
            // Map MongoDB schema to component format
            const mapped = res.data.map((s, idx) => ({
              id: s._id || `speaker-${idx}`,
              name: s.name,
              title: s.designation,
              image: s.photo,
              imagePosition: 'center',
              linkedinUrl: ''
            }));
            setSpeakers(mapped);
          } else {
            setSpeakers([]);
          }
          setError(null);
        }
      } catch (err) {
        console.warn('Could not fetch speakers from API, falling back to local dataset:', err.message);
        if (isMounted) {
          setSpeakers(localData.speakers || []);
          setError('Backend offline: Displaying cached speaker data.');
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    fetchSpeakers();
    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <div className="speakers-page">
      <section className="ws-hero">
        <div className="ws-hero__content">
          <p className="ws-hero__eyebrow">Confluence 3.0</p>
          <h1 className="ws-hero__title">Distinguished Speakers</h1>
          <p className="ws-hero__text">
            Meet the luminaries, policy makers, industry titans, and pioneers who will share transformative perspectives at Confluence 3.0.
          </p>
        </div>
      </section>

      <div style={{ maxWidth: '1200px', margin: '3.5rem auto', padding: '0 1.5rem' }}>
        {loading && (
          <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '4rem 0', gap: '0.75rem', color: '#0A2540' }}>
            <Loader2 className="animate-spin" size={28} />
            <span style={{ fontSize: '1.1rem', fontWeight: 600 }}>Loading speakers...</span>
          </div>
        )}

        {error && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', backgroundColor: '#eff6ff', color: '#1e40af', padding: '0.75rem 1rem', borderRadius: '8px', marginBottom: '2rem', fontSize: '0.9rem' }}>
            <AlertCircle size={18} />
            <span>{error}</span>
          </div>
        )}

        {!loading && speakers.length === 0 && (
          <div style={{ textAlign: 'center', padding: '4rem 0', color: '#64748b' }}>
            <p style={{ fontSize: '1.1rem', fontWeight: 600 }}>No speakers scheduled at this time.</p>
          </div>
        )}

        {!loading && speakers.length > 0 && (
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
              gap: '2rem'
            }}
          >
            {speakers.map((speaker) => (
              <div
                key={speaker.id}
                style={{
                  backgroundColor: '#ffffff',
                  border: '1px solid #e2e8f0',
                  borderRadius: '16px',
                  padding: '2rem 1.5rem',
                  textAlign: 'center',
                  boxShadow: '0 4px 15px rgba(0,0,0,0.03)',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  transition: 'transform 0.2s ease, box-shadow 0.2s ease'
                }}
              >
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                  <div
                    style={{
                      width: '130px',
                      height: '130px',
                      borderRadius: '50%',
                      overflow: 'hidden',
                      marginBottom: '1.25rem',
                      backgroundColor: '#f1f5f9',
                      border: '3px solid #0A2540',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center'
                    }}
                  >
                    {speaker.image ? (
                      <img
                        src={speaker.image.startsWith('http') ? speaker.image : `https://confluence.org.in${speaker.image}`}
                        alt={speaker.name}
                        style={{
                          width: '100%',
                          height: '100%',
                          objectFit: 'cover',
                          objectPosition: speaker.imagePosition || 'center'
                        }}
                        onError={(e) => {
                          e.target.style.display = 'none';
                          if (e.target.nextSibling) {
                            e.target.nextSibling.style.display = 'block';
                          }
                        }}
                      />
                    ) : null}
                    <User size={48} color="#94a3b8" style={{ display: speaker.image ? 'none' : 'block' }} />
                  </div>

                  <h3 style={{ fontSize: '1.2rem', fontWeight: 800, color: '#0A2540', marginBottom: '0.4rem' }}>
                    {speaker.name}
                  </h3>

                  {Array.isArray(speaker.title) ? (
                    speaker.title.map((t, idx) => (
                      <p key={idx} style={{ fontSize: '0.85rem', color: '#475569', lineHeight: 1.4 }}>
                        {t}
                      </p>
                    ))
                  ) : (
                    <p style={{ fontSize: '0.88rem', color: '#475569', lineHeight: 1.4 }}>
                      {speaker.title}
                    </p>
                  )}
                </div>

                {speaker.linkedinUrl && (
                  <div style={{ marginTop: '1.25rem' }}>
                    <a
                      href={speaker.linkedinUrl}
                      target="_blank"
                      rel="noreferrer"
                      style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '0.35rem',
                        color: '#0077b5',
                        fontSize: '0.82rem',
                        fontWeight: 600,
                        textDecoration: 'none'
                      }}
                    >
                      <ExternalLink size={16} /> LinkedIn
                    </a>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
export default Speakers;
