import React, { useState, useEffect } from 'react';
import { ExternalLink, User, Loader2, AlertCircle } from 'lucide-react';
import api from '../services/api';
import localData from '../data.json';

export const AdvisoryBoard = () => {
  const [boardData, setBoardData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let isMounted = true;
    const fetchBoard = async () => {
      try {
        setLoading(true);
        const res = await api.getAdvisoryBoard();
        if (isMounted) {
          if (res.data && res.data.length > 0) {
            // Group by category/organization or display as structured groups
            // To maintain the original layout categories:
            const categoriesMap = new Map();
            localData.advisoryBoard.forEach(c => {
              categoriesMap.set(c.title, { ...c, members: [] });
            });

            // Map incoming members into appropriate categories or single category
            res.data.forEach((member) => {
              let placed = false;
              for (const [title, catObj] of categoriesMap.entries()) {
                const foundInLocal = (localData.advisoryBoard.find(x => x.title === title)?.members || [])
                  .some(m => m.name.toLowerCase() === member.name.toLowerCase());
                if (foundInLocal) {
                  catObj.members.push({
                    name: member.name,
                    designation: member.designation,
                    organization: member.organization,
                    imageUrl: member.photo,
                    linkedinUrl: ''
                  });
                  placed = true;
                  break;
                }
              }
              if (!placed) {
                // Default to advisory committee
                const defaultCat = categoriesMap.get('Advisory Committee') || categoriesMap.values().next().value;
                if (defaultCat) {
                  defaultCat.members.push({
                    name: member.name,
                    designation: member.designation,
                    organization: member.organization,
                    imageUrl: member.photo,
                    linkedinUrl: ''
                  });
                }
              }
            });

            const structured = Array.from(categoriesMap.values()).filter(c => c.members.length > 0);
            setBoardData(structured.length > 0 ? structured : localData.advisoryBoard);
          } else {
            setBoardData([]);
          }
          setError(null);
        }
      } catch (err) {
        console.warn('Could not fetch advisory board from API, falling back to local dataset:', err.message);
        if (isMounted) {
          setBoardData(localData.advisoryBoard || []);
          setError('Backend offline: Displaying cached advisory board.');
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    fetchBoard();
    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <div className="advisory-page">
      <section className="ws-hero">
        <div className="ws-hero__content">
          <p className="ws-hero__eyebrow">Confluence 3.0</p>
          <h1 className="ws-hero__title">Advisory Board</h1>
          <p className="ws-hero__text">
            Guiding the vision and strategic direction of Confluence 3.0 — distinguished patrons, academic leaders, and advisors from Rajagiri and industry.
          </p>
        </div>
      </section>

      <div style={{ maxWidth: '1200px', margin: '3rem auto', padding: '0 1.5rem' }}>
        {loading && (
          <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '4rem 0', gap: '0.75rem', color: '#0A2540' }}>
            <Loader2 className="animate-spin" size={28} />
            <span style={{ fontSize: '1.1rem', fontWeight: 600 }}>Loading advisory board...</span>
          </div>
        )}

        {error && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', backgroundColor: '#eff6ff', color: '#1e40af', padding: '0.75rem 1rem', borderRadius: '8px', marginBottom: '2rem', fontSize: '0.9rem' }}>
            <AlertCircle size={18} />
            <span>{error}</span>
          </div>
        )}

        {!loading && boardData.length === 0 && (
          <div style={{ textAlign: 'center', padding: '4rem 0', color: '#64748b' }}>
            <p style={{ fontSize: '1.1rem', fontWeight: 600 }}>No advisory board information available.</p>
          </div>
        )}

        {!loading && boardData.map((category) => (
          <div key={category.id || category.title} style={{ marginBottom: '4rem' }}>
            <div style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
              <h2 style={{ fontSize: '1.8rem', fontWeight: 800, color: '#0A2540' }}>
                {category.title}
              </h2>
              <div style={{ width: '60px', height: '3px', backgroundColor: '#d4af37', margin: '0.75rem auto 0' }} />
            </div>

            <div
              style={{
                display: 'grid',
                gridTemplateColumns: category.variant === 'spotlight'
                  ? 'minmax(280px, 420px)'
                  : 'repeat(auto-fit, minmax(280px, 1fr))',
                justifyContent: 'center',
                gap: '2rem'
              }}
            >
              {category.members.map((member, mIdx) => (
                <div
                  key={mIdx}
                  style={{
                    backgroundColor: '#ffffff',
                    border: '1px solid #e2e8f0',
                    borderRadius: '16px',
                    padding: '2rem',
                    textAlign: 'center',
                    boxShadow: '0 4px 15px rgba(0,0,0,0.03)',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center'
                  }}
                >
                  <div
                    style={{
                      width: '120px',
                      height: '120px',
                      borderRadius: '50%',
                      overflow: 'hidden',
                      marginBottom: '1.25rem',
                      backgroundColor: '#f1f5f9',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      border: '3px solid #e2e8f0'
                    }}
                  >
                    {member.imageUrl ? (
                      <img
                        src={member.imageUrl.startsWith('http') ? member.imageUrl : `https://confluence.org.in${member.imageUrl}`}
                        alt={member.name}
                        style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                        onError={(e) => {
                          e.target.style.display = 'none';
                          if (e.target.nextSibling) {
                            e.target.nextSibling.style.display = 'block';
                          }
                        }}
                      />
                    ) : null}
                    <User size={48} color="#94a3b8" style={{ display: member.imageUrl ? 'none' : 'block' }} />
                  </div>

                  <h3 style={{ fontSize: '1.15rem', fontWeight: 700, color: '#0f172a', marginBottom: '0.35rem' }}>
                    {member.name}
                  </h3>
                  <p style={{ fontSize: '0.88rem', color: '#0A2540', fontWeight: 600, marginBottom: '0.25rem' }}>
                    {member.designation}
                  </p>
                  {member.organization && (
                    <p style={{ fontSize: '0.8rem', color: '#64748b', lineHeight: 1.4 }}>
                      {member.organization}
                    </p>
                  )}

                  {member.linkedinUrl && (
                    <a
                      href={member.linkedinUrl}
                      target="_blank"
                      rel="noreferrer"
                      style={{
                        marginTop: '1rem',
                        color: '#0077b5',
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '0.35rem',
                        fontSize: '0.85rem',
                        fontWeight: 600,
                        textDecoration: 'none'
                      }}
                      aria-label={`${member.name} LinkedIn Profile`}
                    >
                      <ExternalLink size={16} /> LinkedIn
                    </a>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
export default AdvisoryBoard;
