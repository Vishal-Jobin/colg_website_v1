import React, { useEffect, useState } from 'react';
import { LockKeyhole, LogOut, Plus, Pencil, Trash2, RefreshCw, LayoutDashboard } from 'lucide-react';
import './Admin.css';

const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
const sections = [
  { key: 'workshops', label: 'Workshops', fields: [['title','Title','text',true],['description','Description','textarea'],['instructor','Instructor','text'],['date','Date','date'],['startTime','Start time','text'],['endTime','End time','text'],['venue','Venue','text'],['image','Image URL','url'],['registrationUrl','Registration URL','url'],['capacity','Capacity','number'],['displayOrder','Display order','number']] },
  { key: 'advisory-board', label: 'Advisory board', fields: [['name','Name','text',true],['designation','Designation','text'],['organization','Organization','text'],['biography','Biography','textarea'],['photo','Photo URL','url'],['displayOrder','Display order','number']] },
  { key: 'speakers', label: 'Speakers', fields: [['name','Name','text',true],['designation','Designation','text'],['organization','Organization','text'],['biography','Biography','textarea'],['photo','Photo URL','url'],['sessionTitle','Session title','text'],['displayOrder','Display order','number']] },
  { key: 'sponsors', label: 'Sponsors', fields: [['name','Sponsor name','text',true],['logo','Logo URL','url'],['website','Website','url'],['category','Category','text'],['displayOrder','Display order','number']] },
  { key: 'tickets', label: 'Tickets', fields: [['name','Ticket name','text',true],['description','Description','textarea'],['price','Price (₹)','number',true],['currency','Currency','text'],['benefits','Benefits (one per line)','textarea'],['availabilityStatus','Status','select'],['displayOrder','Display order','number']] },
  { key: 'contact', label: 'Event & contact details', fields: [['title','Event title','text',true],['theme','Event theme','text'],['description','Event description','textarea'],['startDate','Start date','date'],['endDate','End date','date'],['venue','Event venue','textarea'],['heroImage','Hero image URL','url'],['logo','Event logo URL','url'],['registrationUrl','Registration URL','url'],['contactEmail','Contact email','email'],['contactPhone','Contact phone','text'],['contactAddress','Contact address','textarea']] },
  { key: 'registrations', label: 'User registrations', fields: [['fullName','Full name','text',true],['email','Email','email',true],['phone','Phone','text'],['organization','Institution / organization','text'],['designation','Designation','text'],['attendeeType','Pass type','text'],['status','Registration status','select'],['message','Message','textarea']] }
];
const blank = (section) => Object.fromEntries(section.fields.map(([key]) => [key, key === 'currency' ? 'INR' : ['availabilityStatus','status'].includes(key) ? (key === 'status' ? 'pending' : 'available') : '']));
const displayName = (item, section) => item.title || item.name || item.fullName || item.contactEmail || section.label;

export function Admin() {
  const [token, setToken] = useState(() => sessionStorage.getItem('confluence_admin_token') || '');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [sectionKey, setSectionKey] = useState('workshops');
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({});
  const [editing, setEditing] = useState(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const section = sections.find(s => s.key === sectionKey) || sections[0];

  async function request(path, options = {}) {
    const response = await fetch(`${API}${path}`, {
      ...options,
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(options.headers || {}) }
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      if (response.status === 401) logout();
      throw new Error(data.error || 'Request failed.');
    }
    return data;
  }
  function logout() {
    sessionStorage.removeItem('confluence_admin_token');
    setToken(''); setItems([]); setForm({}); setEditing(null);
  }
  async function login(e) {
    e.preventDefault(); setError(''); setBusy(true);
    try {
      const res = await fetch(`${API}/admin/login`, { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ username, password }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Login failed.');
      sessionStorage.setItem('confluence_admin_token', data.token);
      setToken(data.token); setPassword('');
    } catch (err) { setError(err.message); }
    finally { setBusy(false); }
  }
  async function load() {
    if (!token) return;
    setBusy(true); setError('');
    try {
      const data = await request(`/admin/${sectionKey}`);
      const rows = sectionKey === 'contact' ? [data.data || {}] : (data.data || []);
      setItems(rows);
      setForm(blank(section));
      setEditing(null);
    } catch (err) { setError(err.message); }
    finally { setBusy(false); }
  }
  useEffect(() => { load(); }, [token, sectionKey]);
  function startEdit(item) {
    setEditing(item._id || 'contact');
    const next = { ...blank(section), ...item };
    if (Array.isArray(next.benefits)) next.benefits = next.benefits.join('\n');
    for (const [key] of section.fields) {
      if (key.toLowerCase().includes('date') && next[key]) next[key] = String(next[key]).slice(0,10);
    }
    setForm(next); setMessage('');
  }
  function change(key, value) { setForm(prev => ({...prev, [key]: value})); }
  async function save(e) {
    e.preventDefault(); setError(''); setMessage(''); setBusy(true);
    const payload = { ...form };
    for (const [key,,type] of section.fields) {
      if (type === 'number') payload[key] = payload[key] === '' ? undefined : Number(payload[key]);
    }
    if (sectionKey === 'registrations') {
      try { await request(`/admin/registrations/${editing}`, { method: 'PUT', body: JSON.stringify({ status: payload.status }) }); setMessage('Registration status updated.'); await load(); } catch (err) { setError(err.message); } finally { setBusy(false); }
      return;
    }
    if (sectionKey === 'tickets') payload.benefits = String(payload.benefits || '').split('\n').map(x => x.trim()).filter(Boolean);
    try {
      if (sectionKey === 'contact') {
        await request('/admin/contact/contact', { method: 'PUT', body: JSON.stringify(payload) });
      } else if (editing) {
        await request(`/admin/${sectionKey}/${editing}`, { method: 'PUT', body: JSON.stringify(payload) });
      } else {
        await request(`/admin/${sectionKey}`, { method: 'POST', body: JSON.stringify(payload) });
      }
      setMessage('Saved successfully. The database has been updated.');
      await load();
    } catch (err) { setError(err.message); }
    finally { setBusy(false); }
  }
  async function remove(item) {
    if (!window.confirm(`Delete "${displayName(item, section)}"? This cannot be undone.`)) return;
    setError(''); setMessage('');
    try {
      await request(`/admin/${sectionKey}/${item._id}`, { method: 'DELETE' });
      setMessage('Deleted successfully.'); await load();
    } catch (err) { setError(err.message); }
  }

  if (!token) return <div className="admin-login-wrap"><form className="admin-login-card" onSubmit={login}>
    <div className="admin-brand-icon"><LockKeyhole size={28}/></div>
    <p className="admin-eyebrow">CONFLUENCE 3.0</p><h1>Admin portal</h1>
    <p className="admin-muted">Sign in to manage your website content.</p>
    {error && <div className="admin-alert error">{error}</div>}
    <label>Username<input autoComplete="username" value={username} onChange={e=>setUsername(e.target.value)} required /></label>
    <label>Password<input type="password" autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)} required /></label>
    <button className="admin-primary" disabled={busy}>{busy ? 'Signing in…' : 'Sign in securely'}</button>
    <a href="/" className="admin-back-link">← Back to website</a>
  </form></div>;

  return <div className="admin-shell">
    <aside className="admin-sidebar">
      <div className="admin-side-brand"><LayoutDashboard/><div><b>Confluence</b><small>Admin console</small></div></div>
      <p className="admin-nav-caption">CONTENT MANAGEMENT</p>
      {sections.map(s=><button key={s.key} className={`admin-nav-item ${sectionKey===s.key?'active':''}`} onClick={()=>{setSectionKey(s.key);setMessage('');setError('')}}>{s.label}</button>)}
      <button className="admin-logout" onClick={logout}><LogOut size={17}/> Sign out</button>
    </aside>
    <main className="admin-main">
      <header className="admin-topbar"><div><p className="admin-eyebrow">WEBSITE MANAGEMENT</p><h1>{section.label}</h1></div><button className="admin-secondary" onClick={load}><RefreshCw size={16}/> Refresh</button></header>
      {error && <div className="admin-alert error">{error}</div>}{message && <div className="admin-alert success">{message}</div>}
      <div className="admin-workspace">
        <section className="admin-panel">
          <div className="admin-panel-heading"><div><h2>{editing ? 'Edit details' : sectionKey==='contact' ? 'Update details' : sectionKey==='registrations' ? 'Manage registration' : `Add ${section.label.toLowerCase().replace(/s$/,'')}`}</h2><p>{sectionKey==='registrations' ? 'Select a registration to update its status.' : 'Changes are saved directly to MongoDB and appear on the public site.'}</p></div>{editing && <button className="admin-secondary" onClick={()=>{setEditing(null);setForm(blank(section))}}>Cancel edit</button>}</div>
          {sectionKey !== 'registrations' || editing ? <form className="admin-form" onSubmit={save}>
            {section.fields.filter(([key]) => sectionKey !== 'registrations' || ['status'].includes(key)).map(([key,label,type,required])=><label key={key}>{label}{type==='textarea' ? <textarea rows={3} value={form[key] ?? ''} required={required} onChange={e=>change(key,e.target.value)}/> : type==='select' ? <select value={form[key] || 'available'} onChange={e=>change(key,e.target.value)}>{key === 'status' ? <><option value="pending">Pending</option><option value="confirmed">Confirmed</option><option value="cancelled">Cancelled</option></> : <><option value="available">Available</option><option value="limited">Limited</option><option value="sold_out">Sold out</option><option value="upcoming">Upcoming</option></>}</select> : <input type={type} value={form[key] ?? ''} required={required} onChange={e=>change(key,e.target.value)}/>}</label>)}
            <button className="admin-primary" disabled={busy}><Plus size={17}/>{busy ? 'Saving…' : editing ? 'Save changes' : sectionKey==='contact' ? 'Update contact details' : 'Add to website'}</button>
          </form> : <p className="admin-empty">Choose a registration from the list to change its status.</p>}
        </section>
        <section className="admin-panel admin-list-panel">
          <div className="admin-panel-heading"><div><h2>Current {section.label.toLowerCase()}</h2><p>{items.length} record{items.length===1?'':'s'} in the database</p></div></div>
          {busy && !items.length ? <p className="admin-muted">Loading content…</p> : !items.length ? <p className="admin-empty">No records found in this section yet.</p> : <div className="admin-record-list">{items.map((item,i)=><div className="admin-record" key={item._id || i}><div className="admin-record-copy"><b>{displayName(item,section)}</b><small>{item.email || item.designation || item.instructor || item.category || (item.price !== undefined ? `₹${item.price}` : '') || item.contactPhone || item.venue || (item.status ? `Status: ${item.status}` : 'Website content')} {item.status && item.email ? `• ${item.status}` : ''}</small></div><div className="admin-record-actions"><button aria-label="Edit" onClick={()=>startEdit(item)}><Pencil size={16}/></button>{sectionKey!=='contact' && <button aria-label="Delete" className="delete" onClick={()=>remove(item)}><Trash2 size={16}/></button>}</div></div>)}</div>}
        </section>
      </div>
      <p className="admin-footer-note">Admin access is private. Sign out when finished, especially on shared devices.</p>
    </main>
  </div>;
}
