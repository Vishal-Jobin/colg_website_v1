import React, { useState, useEffect } from 'react';
import { Check, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';
import api from '../services/api';
import localData from '../data.json';

export const Tickets = () => {
  const [tickets, setTickets] = useState([]);
  const [loadingTickets, setLoadingTickets] = useState(true);
  const [selectedPass, setSelectedPass] = useState('business');
  const [selectedTicketId, setSelectedTicketId] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    institution: ''
  });
  const [status, setStatus] = useState({ loading: false, error: null, success: null });

  useEffect(() => {
    let isMounted = true;
    const fetchTickets = async () => {
      try {
        setLoadingTickets(true);
        const res = await api.getTickets();
        if (isMounted) {
          if (res.data && res.data.length > 0) {
            // Map MongoDB ticketType documents to presentation format
            const mapped = res.data.map((t, idx) => {
              const matchedLocal = localData.tickets.find(
                lt => lt.title.toLowerCase() === t.name.toLowerCase() || lt.id === t.name.toLowerCase()
              );
              const passSlug = matchedLocal ? matchedLocal.id : (idx === 0 ? 'business' : idx === 1 ? 'academic' : 'young');
              return {
                id: passSlug,
                mongoId: t._id,
                title: t.name,
                forText: t.description || (matchedLocal ? matchedLocal.forText : ''),
                color: matchedLocal ? matchedLocal.color : '#0A2540',
                features: t.benefits && t.benefits.length > 0
                  ? t.benefits.map(b => ({ text: b, included: true }))
                  : (matchedLocal ? matchedLocal.features : [])
              };
            });
            setTickets(mapped);
            if (mapped.length > 0) {
              setSelectedPass(mapped[0].id);
              setSelectedTicketId(mapped[0].mongoId);
            }
          } else {
            setTickets(localData.tickets || []);
          }
        }
      } catch (err) {
        console.warn('Could not fetch tickets from API, falling back to local dataset:', err.message);
        if (isMounted) {
          setTickets(localData.tickets || []);
        }
      } finally {
        if (isMounted) setLoadingTickets(false);
      }
    };

    fetchTickets();
    return () => {
      isMounted = false;
    };
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    if (status.error) setStatus({ ...status, error: null });
  };

  const handleSelectPass = (ticket) => {
    setSelectedPass(ticket.id);
    setSelectedTicketId(ticket.mongoId || null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.email.trim()) {
      setStatus({ loading: false, error: 'Please fill in your name and email.', success: null });
      return;
    }

    setStatus({ loading: true, error: null, success: null });
    try {
      const payload = {
        fullName: formData.name.trim(),
        email: formData.email.trim(),
        phone: formData.phone.trim(),
        organization: formData.institution.trim(),
        attendeeType: selectedPass,
        ticketType: selectedTicketId
      };

      const resData = await api.submitRegistration(payload);

      setStatus({
        loading: false,
        error: null,
        success: resData.message || 'Your registration interest has been recorded successfully in MongoDB! Our team will contact you.'
      });
      setFormData({ name: '', email: '', phone: '', institution: '' });
    } catch (err) {
      setStatus({
        loading: false,
        error: err.message || 'Failed to submit registration. Please try again.',
        success: null
      });
    }
  };

  const displayedTickets = tickets.length > 0 ? tickets : localData.tickets;

  return (
    <div className="tickets-page">
      <section className="tickets-hero" style={{ background: '#0A2540', padding: '5rem 1.5rem', textAlign: 'center', color: '#fff' }}>
        <p className="tickets-hero__eyebrow" style={{ textTransform: 'uppercase', letterSpacing: '2px', color: '#d4af37', fontSize: '0.9rem', fontWeight: 700 }}>
          Registration Passes
        </p>
        <h1 className="tickets-hero__title" style={{ fontSize: '2.5rem', fontWeight: 900, marginTop: '0.5rem' }}>
          Confluence 3.0 Tickets
        </h1>
        <p style={{ color: '#94a3b8', maxWidth: '600px', margin: '0.75rem auto 0' }}>
          Select the delegate category best suited for your profile and participate in keynotes, panel discussions, and hands-on workshops.
        </p>
      </section>

      <div style={{ maxWidth: '1200px', margin: '3.5rem auto', padding: '0 1.5rem' }}>
        {loadingTickets && (
          <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '2rem 0', gap: '0.75rem', color: '#0A2540' }}>
            <Loader2 className="animate-spin" size={24} />
            <span style={{ fontSize: '1rem', fontWeight: 600 }}>Loading available ticket passes...</span>
          </div>
        )}

        {/* Pass Selection Cards */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
            gap: '2rem',
            marginBottom: '4rem'
          }}
        >
          {displayedTickets.map((ticket) => {
            const isSelected = selectedPass === ticket.id;
            return (
              <div
                key={ticket.id}
                onClick={() => handleSelectPass(ticket)}
                style={{
                  backgroundColor: '#ffffff',
                  border: isSelected ? `2.5px solid ${ticket.color || '#0A2540'}` : '1px solid #e2e8f0',
                  borderRadius: '16px',
                  padding: '2.25rem 1.75rem',
                  cursor: 'pointer',
                  position: 'relative',
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'space-between',
                  boxShadow: isSelected ? '0 12px 30px rgba(0,0,0,0.1)' : '0 4px 15px rgba(0,0,0,0.03)',
                  transform: isSelected ? 'translateY(-4px)' : 'none',
                  transition: 'all 0.2s ease'
                }}
              >
                {isSelected && (
                  <span
                    style={{
                      position: 'absolute',
                      top: '1rem',
                      right: '1rem',
                      backgroundColor: ticket.color || '#0A2540',
                      color: '#fff',
                      fontSize: '0.75rem',
                      fontWeight: 700,
                      padding: '0.2rem 0.6rem',
                      borderRadius: '999px'
                    }}
                  >
                    Selected
                  </span>
                )}

                <div>
                  <h3 style={{ fontSize: '1.35rem', fontWeight: 800, color: ticket.color || '#0A2540' }}>
                    {ticket.title}
                  </h3>
                  <p style={{ fontSize: '0.85rem', color: '#64748b', marginTop: '0.25rem', marginBottom: '1.5rem' }}>
                    {ticket.forText}
                  </p>

                  <ul style={{ listStyle: 'none', padding: 0, margin: '0 0 2rem 0' }}>
                    {(ticket.features || []).map((f, fIdx) => (
                      <li
                        key={fIdx}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '0.6rem',
                          fontSize: '0.9rem',
                          color: f.included ? '#334155' : '#94a3b8',
                          marginBottom: '0.75rem',
                          textDecoration: f.included ? 'none' : 'line-through'
                        }}
                      >
                        <Check size={16} color={f.included ? '#16a34a' : '#cbd5e1'} />
                        {f.text}
                      </li>
                    ))}
                  </ul>
                </div>

                <button
                  type="button"
                  style={{
                    backgroundColor: isSelected ? (ticket.color || '#0A2540') : '#f1f5f9',
                    color: isSelected ? '#fff' : '#334155',
                    border: 'none',
                    padding: '0.85rem',
                    borderRadius: '8px',
                    fontWeight: 700,
                    cursor: 'pointer',
                    width: '100%',
                    textAlign: 'center'
                  }}
                >
                  {isSelected ? 'Pass Selected' : 'Select Pass'}
                </button>
              </div>
            );
          })}
        </div>

        {/* Registration Interest Form */}
        <div
          style={{
            maxWidth: '650px',
            margin: '0 auto',
            backgroundColor: '#ffffff',
            border: '1px solid #e2e8f0',
            borderRadius: '16px',
            padding: '2.5rem',
            boxShadow: '0 4px 20px rgba(0,0,0,0.05)'
          }}
        >
          <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
            <h2 style={{ fontSize: '1.5rem', fontWeight: 800, color: '#0A2540' }}>
              Register Your Interest
            </h2>
            <p style={{ fontSize: '0.88rem', color: '#64748b', marginTop: '0.35rem' }}>
              Submitting for: <strong style={{ color: '#0A2540', textTransform: 'capitalize' }}>{selectedPass} Leader Pass</strong>
            </p>
          </div>

          {status.error && (
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.6rem',
                backgroundColor: '#fef2f2',
                color: '#dc2626',
                padding: '1rem',
                borderRadius: '8px',
                marginBottom: '1.5rem',
                fontSize: '0.9rem'
              }}
            >
              <AlertCircle size={20} />
              <span>{status.error}</span>
            </div>
          )}

          {status.success && (
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.6rem',
                backgroundColor: '#f0fdf4',
                color: '#16a34a',
                padding: '1rem',
                borderRadius: '8px',
                marginBottom: '1.5rem',
                fontSize: '0.9rem'
              }}
            >
              <CheckCircle2 size={20} />
              <span>{status.success}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, color: '#334155', marginBottom: '0.35rem' }}>
                Full Name *
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                placeholder="Dr. / Mr. / Ms. Jane Doe"
                style={{
                  width: '100%',
                  padding: '0.75rem 1rem',
                  borderRadius: '8px',
                  border: '1px solid #cbd5e1',
                  fontSize: '0.95rem'
                }}
              />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, color: '#334155', marginBottom: '0.35rem' }}>
                Email Address *
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                placeholder="jane@example.com"
                style={{
                  width: '100%',
                  padding: '0.75rem 1rem',
                  borderRadius: '8px',
                  border: '1px solid #cbd5e1',
                  fontSize: '0.95rem'
                }}
              />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, color: '#334155', marginBottom: '0.35rem' }}>
                Phone Number
              </label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                placeholder="+91 9876543210"
                style={{
                  width: '100%',
                  padding: '0.75rem 1rem',
                  borderRadius: '8px',
                  border: '1px solid #cbd5e1',
                  fontSize: '0.95rem'
                }}
              />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 600, color: '#334155', marginBottom: '0.35rem' }}>
                College / Institution / Organization
              </label>
              <input
                type="text"
                name="institution"
                value={formData.institution}
                onChange={handleChange}
                placeholder="Rajagiri / Tech Company"
                style={{
                  width: '100%',
                  padding: '0.75rem 1rem',
                  borderRadius: '8px',
                  border: '1px solid #cbd5e1',
                  fontSize: '0.95rem'
                }}
              />
            </div>

            <button
              type="submit"
              disabled={status.loading}
              style={{
                backgroundColor: '#0A2540',
                color: '#ffffff',
                border: 'none',
                padding: '1rem',
                borderRadius: '8px',
                fontSize: '1rem',
                fontWeight: 700,
                cursor: status.loading ? 'not-allowed' : 'pointer',
                marginTop: '0.5rem',
                boxShadow: '0 4px 12px rgba(10, 37, 64, 0.2)'
              }}
            >
              {status.loading ? 'Submitting...' : 'Submit Registration Interest'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
export default Tickets;
