# Confluence 3.0 Website — Full MERN Stack with MongoDB Integration

A full-stack MERN application for **Confluence 3.0** (organised by Rajagiri School of Engineering & Technology - RSET). This project integrates a complete MongoDB database and Express.js REST API with the existing React + Vite frontend, maintaining original layouts, styling, responsive behaviors, and hash-based routes.

Reference website: https://confluence.org.in/#/

---

## 1. Directory Structure

The repository adheres strictly to the mandatory `frontend/` and `backend/` organization:

```text
confluence-website/
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── assets/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── services/
│   │   │   └── api.js          # Centralized API service helper
│   │   ├── data.json
│   │   ├── App.jsx             # HashRouter and view layout
│   │   ├── main.jsx
│   │   └── index.css
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
│
├── backend/
│   ├── config/
│   │   └── db.js               # MongoDB connection manager (Atlas & Local)
│   ├── models/
│   │   ├── Speaker.js          # Speaker collection model
│   │   ├── AdvisoryBoard.js    # Advisory board collection model
│   │   ├── Workshop.js         # Workshop collection model
│   │   ├── Sponsor.js          # Sponsor and partner collection model
│   │   ├── ScheduleItem.js     # Summit schedule with speaker references
│   │   ├── TicketType.js       # Summit pass tier model
│   │   ├── Registration.js     # Attendee registration interest model
│   │   ├── ContactMessage.js   # Contact form submissions model
│   │   └── Event.js            # Summit global metadata model
│   ├── controllers/
│   │   ├── contentController.js
│   │   ├── registrationController.js
│   │   └── contactController.js
│   ├── routes/
│   │   └── api.js              # Centralized Express route definitions
│   ├── middleware/
│   │   ├── common.js           # DB connection checker and error handler
│   │   └── rateLimiter.js      # Rate limiting on public submissions
│   ├── scripts/
│   │   └── seed.js             # Idempotent database seeder
│   ├── app.js                  # Express app setup and CORS configuration
│   ├── server.js               # Server startup & DB connection listener
│   └── package.json
│
├── .env
├── .env.example
├── .gitignore
├── package.json                # Root package for concurrent multi-package execution
└── README.md
```

---

## 2. Prerequisites

- **Node.js**: v18.0.0 or higher (v20+ recommended)
- **npm**: v9.0.0 or higher
- **MongoDB**: Local MongoDB instance (running on `mongodb://127.0.0.1:27017`) or a free [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) cluster connection string.

---

## 3. Environment Configuration

### Root `.env` (Backend Configuration)

A `.env.example` file is included in the project root:

```env
PORT=5000
MONGODB_URI=mongodb://127.0.0.1:27017/confluence_db
CLIENT_URL=http://localhost:5173
NODE_ENV=development
```

To configure your environment:
1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
2. Replace `MONGODB_URI` with your connection string:
   - **Local MongoDB**: `mongodb://127.0.0.1:27017/confluence_db`
   - **MongoDB Atlas**: `mongodb+srv://<username>:<password>@<cluster-url>/confluence_db?retryWrites=true&w=majority`

### Frontend `.env` (Client Configuration)

`frontend/.env` contains the API base URL:
```env
VITE_API_URL=http://localhost:5000/api
```

---

## 4. Installation

Install dependencies across the root, backend, and frontend with a single command from the root directory:

```bash
npm run install:all
```

Or install individually:
```bash
npm install
cd backend && npm install
cd ../frontend && npm install
```

---

## 5. Database Seeding

The backend includes an idempotent seed script in `backend/scripts/seed.js` that populates MongoDB with verified Confluence 3.0 event content (speakers, advisory board, workshops, sponsors, schedule, tickets, and event metadata).

To seed the database:
```bash
npm run seed
```
*(or run `npm run seed` directly inside the `backend/` directory)*

### Seeding Safety Guarantees:
- Safe to rerun repeatedly: uses `findOneAndUpdate` with unique filters to prevent duplicate documents.
- Preserves user registrations and contact messages (does not wipe user-submitted records).
- All seeded records are tagged with `isActive: true` and indexed display orders.

---

## Admin dashboard and registrations

- Open the admin page at `http://localhost:5173/#/admin`.
- Configure `ADMIN_USERNAME`, `ADMIN_PASSWORD`, and `ADMIN_TOKEN_SECRET` in the project-root `.env` (copy `.env.example` first). The backend also supports `backend/.env` if no root `.env` is present. Do not use the example password in production.
- The admin dashboard can add, edit, and delete speakers, advisory-board members, workshops, sponsors, and ticket types. The Event & contact details section updates the event metadata shown on the public website.
- User registrations submitted from the Tickets page are saved in MongoDB. The User registrations section lets the admin review them, change their status to pending/confirmed/cancelled, or delete a record.
- Public pages read content from the API, so the backend and MongoDB must be running for edits and registrations to persist. After saving, refresh the relevant public page to see the changes.

## 6. Running the Application

### Start Frontend and Backend Together (Recommended)
Run both services with one command from the project root:
```bash
npm run dev
```

### Start Individual Services
- **Run Frontend only:**
  ```bash
  npm run dev:frontend
  ```
  Accessible at [http://localhost:5173](http://localhost:5173).

- **Run Backend only:**
  ```bash
  npm run dev:backend
  ```
  Accessible at [http://localhost:5000](http://localhost:5000).

- **Build Frontend for Production:**
  ```bash
  npm run build
  ```

---

## 7. REST API Endpoints

All endpoints are prefixed with `/api`.

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/health` | Health check endpoint returning server and database connectivity status |
| `GET` | `/api/event` | Event-wide metadata (title, theme, dates, banner) |
| `GET` | `/api/speakers` | Active distinguished speakers ordered by `displayOrder` |
| `GET` | `/api/advisory-board` | Active advisory board members ordered by `displayOrder` |
| `GET` | `/api/workshops` | Active workshops with instructor and venue details |
| `GET` | `/api/sponsors` | Active sponsors and partner organizations grouped by category |
| `GET` | `/api/schedule` | Programme schedule timeline items (supports optional `?day=1` or `?day=2` filter) |
| `GET` | `/api/tickets` | Available summit delegate passes and ticket information |
| `POST` | `/api/registrations` | Submits attendee registration interest to MongoDB with validation |
| `POST` | `/api/contact` | Submits contact inquiry message to MongoDB with validation |

### Submission Payloads

#### `POST /api/registrations`
```json
{
  "fullName": "Jane Doe",
  "email": "jane@example.com",
  "phone": "+91 9876543210",
  "organization": "Rajagiri School of Engineering",
  "attendeeType": "business",
  "ticketType": "<optional TicketType ObjectId>"
}
```

#### `POST /api/contact`
```json
{
  "name": "John Smith",
  "email": "john@example.com",
  "subject": "Workshops & campus access",
  "message": "Inquiry regarding the hands-on sessions schedule."
}
```

---

## 8. Security & Validation Best Practices Implemented

- **CORS Protection:** Configured with origin validation restricting incoming requests to the frontend origin.
- **Rate Limiting:** Public submission endpoints (`/api/registrations` and `/api/contact`) are rate-limited via `express-rate-limit` to prevent spam/abuse.
- **Request Size Limiting:** Express body parser configured with `100kb` cap to defend against payload overflow attacks.
- **Data Validation & Sanitization:**
  - Names, titles, and text inputs are trimmed and length-bounded.
  - Normalized email addresses with lowercase conversion and RFC-compliant regular expression validation.
  - Required fields verified on both client and server.
- **Centralized Error Handling:** Standardized JSON error responses without exposing raw stack traces.
- **Environment Isolation:** Secrets and MongoDB URI are isolated in server-side `.env` and excluded via `.gitignore`.
- **Honest Persistence:** Frontend notifies the user only after MongoDB confirms document creation. In the event of network or server failure, informative error messages are displayed.

---

## 9. Troubleshooting

1. **Database connection failed / 503 Service Unavailable:**
   - Verify that your local MongoDB service is running:
     ```powershell
     Get-Service -Name MongoDB
     # or start it via:
     net start MongoDB
     ```
   - For Atlas, verify that your IP address is whitelisted in Atlas Network Access and credentials are correct in `.env`.

2. **Port 5000 or 5173 already in use:**
   - Change `PORT` in `.env` to another port (e.g. `5001`), and update `VITE_API_URL=http://localhost:5001/api` in `frontend/.env`.

3. **PowerShell script execution policy error:**
   - If `npm` scripts are blocked on Windows PowerShell, run scripts using `cmd /c npm run <script>` or execute `Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned`.
